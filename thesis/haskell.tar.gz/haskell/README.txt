This archive contains accompanying Haskell code for the PhD thesis "Towards Safe and Efficient Functional Reactive Programming".

It has been tested under Haskell 2010 using the Glasgow Haskell Compiler (version 6.12.1).
