module Time where

-------------------------------------------------------------------------------

type Time        = Double

type Dt          = Time
type CurrentTime = Time
type ReleaseTime = Time
type EventTime   = Time

-------------------------------------------------------------------------------
