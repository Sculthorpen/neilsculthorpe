{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, InstanceSigs, RankNTypes, ConstraintKinds, ScopedTypeVariables #-}

module Codensity where

import Control.Applicative

--------------------------------------------------------------------

-- Continuation Transformer

newtype ContT r t a = ContT {runContT :: (a -> t r) -> t r}

instance Monad (ContT r t) where
  return :: a -> ContT r t a
  return a = ContT (\ h -> h a)

  (>>=) :: ContT r t a -> (a -> ContT r t b) -> ContT r t b
  ca >>= k = ContT (\ br -> runContT ca (\ a -> runContT (k a) br))

liftContT :: (t a -> (a -> t r) -> t r) -> t a -> ContT r t a
liftContT bind ta = ContT (bind ta)

lowerContT :: (r -> t r) -> ContT r t r -> t r
lowerContT ret ca = runContT ca ret

--------------------------------------------------------------------

-- Codensity Transformer

newtype CodT t a = CodT {runCodT :: forall r. (a -> t r) -> t r}

instance Monad (CodT t) where
  return :: a -> CodT t a
  return a = CodT (\ h -> h a)

  (>>=) :: CodT t a -> (a -> CodT t b) -> CodT t b
  ca >>= k = CodT (\ br -> runCodT ca (\ a -> runCodT (k a) br))

liftCodT :: (forall r. t a -> (a -> t r) -> t r) -> t a -> CodT t a
liftCodT bind ta = CodT (bind ta)

lowerCodT :: (a -> t a) -> CodT t a -> t a
lowerCodT ret ca = runCodT ca ret

--------------------------------------------------------------------

-- Restricted Codensity Transformer

newtype RCodT c t a = RCodT {runRCodT :: forall r. c r => (a -> t r) -> t r}

instance Monad (RCodT c t) where
  return :: a -> RCodT c t a
  return a = RCodT (\ h -> h a)

  (>>=) :: RCodT c t a -> (a -> RCodT c t b) -> RCodT c t b
  ca >>= k = RCodT (\ br -> runRCodT ca (\ a -> runRCodT (k a) br))

liftRCodT :: (forall r. c r => t a -> (a -> t r) -> t r) -> t a -> RCodT c t a
liftRCodT bind ta = RCodT (bind ta)

lowerRCodT :: c a => (a -> t a) -> RCodT c t a -> t a
lowerRCodT ret ra = runRCodT ra ret


instance Functor (RCodT c t) where
  fmap :: (a -> b) -> RCodT c t a -> RCodT c t b
  fmap g ra = RCodT (\ br -> runRCodT ra (\ a -> br (g a)))


instance Applicative (RCodT c t) where
  pure :: a -> RCodT c t a
  pure = return

  (<*>) :: RCodT c t (a -> b) -> RCodT c t a -> RCodT c t b
  rg <*> ra = RCodT (\ br -> runRCodT rg (\ g -> runRCodT ra (\ a -> br (g a))))

--------------------------------------------------------------------

-- Yoneda Transformer

newtype Yoneda t a = Yoneda {runYoneda :: forall r. (a -> r) -> t r}

instance Functor (Yoneda t) where
  fmap :: (a -> b) -> Yoneda t a -> Yoneda t b
  fmap g ya = Yoneda (\ br -> runYoneda ya (\ a -> br (g a)))

liftYoneda :: (forall r. (a -> r) -> f a -> f r) -> f a -> Yoneda f a
liftYoneda fmp fa = Yoneda (\ ar -> fmp ar fa)

lowerYoneda :: Yoneda f a -> f a
lowerYoneda (Yoneda c) = c id

instance Monad m => Monad (Yoneda m) where
  return :: a -> Yoneda m a
  return a = Yoneda (\ ar -> return (ar a))

  (>>=) :: Yoneda m a -> (a -> Yoneda m b) -> Yoneda m b
  ya >>= k = Yoneda (\ br -> runYoneda ya id >>= (\ a -> runYoneda (k a) br))

--------------------------------------------------------------------

-- Restricted Yoneda Transformer

newtype RYoneda c t a = RYoneda {runRYoneda :: forall r. c r => (a -> r) -> t r}

instance Functor (RYoneda c t) where
  fmap :: (a -> b) -> RYoneda c t a -> RYoneda c t b
  fmap g ya = RYoneda (\ br -> runRYoneda ya (\ a -> br (g a)))

liftRYoneda :: (forall r. c r => (a -> r) -> t a -> t r) -> t a -> RYoneda c t a
liftRYoneda fmp ta = RYoneda (\ ar -> fmp ar ta)

lowerRYoneda :: c a => RYoneda c t a -> t a
lowerRYoneda (RYoneda ya) = ya id

--------------------------------------------------------------------

-- An Applicative-Functor Transformer

newtype AFT t a = AFT {runApFun :: forall r. t (a -> r) -> t r}

instance Functor t => Functor (AFT t) where
   fmap :: (a -> b) -> AFT t a -> AFT t b
   fmap = (<$>)

instance Applicative t => Applicative (AFT t) where
   pure :: forall a. a -> AFT t a
   pure a = AFT (\ h -> h <*> pure a)

   (<*>) :: forall a b. AFT t (a -> b) -> AFT t a -> AFT t b
   rg <*> ra = AFT (\ h -> runApFun ra (runApFun rg (pure (.) <*> h)))

liftAFT :: (forall r. t (a -> r) -> t a -> t r) -> t a -> AFT t a
liftAFT app ta = AFT (\ tar -> app tar ta)

lowerAFT :: (forall x. x -> t x) -> AFT t a -> t a
lowerAFT pur ra = runApFun ra (pur id)

--------------------------------------------------------------------
