{-# LANGUAGE RankNTypes, KindSignatures, GADTs, ConstraintKinds, ScopedTypeVariables #-}

import GHC.Exts (Constraint)

import Control.Monad.Operational

import ClassSynonyms

import Set
import Vector

------------------------------------------------------------------

liftProg :: t a -> Program t a
liftProg = singleton

foldProg :: forall a r t. (a -> r) -> (forall x. t x -> (x -> r) -> r) -> Program t a -> r
foldProg ret bind = foldProg'
  where
    foldProg' :: Program t a -> r
    foldProg' p = case view p of
                    Return a   -> ret a
                    tx :>>= k  -> bind tx (foldProg' . k)

lowerProg :: (a -> t a) -> (forall x. t x -> (x -> t a) -> t a) -> Program t a -> t a
lowerProg = foldProg

------------------------------------------------------------------

lowerSet :: Ord a => Program Set a -> Set a
lowerSet = lowerProg returnSet bindSet

s1 :: Program Set (Int,Char)
s1 = do  n <- liftProg (fromList [3,2,1,2])
         c <- liftProg (fromList ['a','b'])
         return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet s1)

------------------------------------------------------------------

data FinVec :: * -> * where
  FV :: Finite a => Vec a -> FinVec a

lowerVec :: Eq a => Program FinVec a -> Vec a
lowerVec = foldProg returnVec (\ (FV vx) k -> bindVec vx k)

------------------------------------------------------------------

data Box :: (* -> Constraint) -> (* -> *) -> * -> * where
  Box :: c a => t a -> Box c t a

unBox :: Box c t a -> t a
unBox (Box ta) = ta

------------------------------------------------------------------

liftBox :: c a => t a -> Program (Box c t) a
liftBox = liftProg . Box

------------------------------------------------------------------

lowerBox :: c a => (a -> t a) -> (forall x. c x => t x -> (x -> t a) -> t a) -> Program (Box c t) a -> t a
lowerBox ret bind = foldProg ret (\ (Box tx) k -> bind tx k)

------------------------------------------------------------------

lowerBoxSet :: Ord a => Program (Box Unconstrained Set) a -> Set a
lowerBoxSet = lowerBox returnSet bindSet

s1' :: (c Char, c Int) => Program (Box c Set) (Int,Char)
s1' = do  n <- liftBox (fromList [3,2,1,2])
          c <- liftBox (fromList ['a','b'])
          return (n,c)

eg1' :: [(Int,Char)]
eg1' = toList (lowerBoxSet s1')

------------------------------------------------------------------
