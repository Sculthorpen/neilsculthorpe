{-# LANGUAGE KindSignatures, FlexibleInstances, InstanceSigs #-}

module Sunroof where

-----------------------------------------------------------------

string :: String -> JSString
string s = JSString ("\"" ++ s ++ "\"")

(<>) :: JSString -> JSString -> JSString
(<>) (JSString a) (JSString b) = JSString (a ++ "+" ++ b)

-----------------------------------------------------------------

class Show a => Sunroof (a :: *) where
  mkVar :: String -> a

  showJS :: a -> JSCode
  showJS = show

  assignVar :: a -> JSCode -> JSCode
  assignVar a b = showJS a ++ "=" ++ b ++ ";"


instance Sunroof JSString where
  mkVar :: String -> JSString
  mkVar = JSString


instance Sunroof JSBool where
  mkVar :: String -> JSBool
  mkVar = JSBool


instance Sunroof () where
  mkVar :: String -> ()
  mkVar _ = ()

  showJS :: () -> JSCode
  showJS _ = "null"

  assignVar :: () -> JSCode -> JSCode
  assignVar () _ = ""


newtype JSString = JSString String
newtype JSBool   = JSBool String

instance Show JSString where
  show (JSString txt) = txt

instance Show JSBool where
  show (JSBool txt) = txt

-----------------------------------------------------------------

type JSCode = String

data CompM a = CompM { runCompM :: Int -> (a, Int) }

instance Monad CompM where
  return :: a -> CompM a
  return a = CompM (\ i -> (a,i))

  (>>=) :: CompM a -> (a -> CompM b) -> CompM b
  (CompM m) >>= k = CompM $ \ i0 -> let (a,i1) = m i0
                                    in runCompM (k a) i1

newVar :: Sunroof a => CompM (JSCode, a)
newVar = CompM $ \ i -> let var = "v" ++ show i
                        in (("var " ++ var ++ ";", mkVar var), i + 1)

-----------------------------------------------------------------
