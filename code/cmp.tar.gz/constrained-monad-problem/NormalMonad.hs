{-# LANGUAGE GADTs, KindSignatures, ConstraintKinds, RankNTypes, InstanceSigs, ScopedTypeVariables #-}

module NormalMonad where

import GHC.Exts (Constraint)

import Set
import Vector
import Sunroof
import PP
import ClassSynonyms

-------------------------------------------------------------------------------------------------

data NM :: (* -> Constraint) -> (* -> *) -> * -> * where
  Return  :: a                              -> NM c t a
  Bind    :: c x => t x -> (x -> NM c t a)  -> NM c t a

-------------------------------------------------------------------------------------------------

instance Monad (NM c t) where
  return :: a -> NM c t a
  return = Return

  (>>=) :: NM c t a -> (a -> NM c t b) -> NM c t b
  (Return a)   >>= k  = k a                         -- left identity
  (Bind tx h)  >>= k  = Bind tx (\ x -> h x >>= k)  -- associativity

-------------------------------------------------------------------------------------------------

liftNM :: c a => t a -> NM c t a
liftNM ta = Bind ta Return -- right identity

-------------------------------------------------------------------------------------------------

foldNM :: forall a c r t. (a -> r) -> (forall x. c x => t x -> (x -> r) -> r) -> NM c t a -> r
foldNM ret bind = foldNM'
  where
    foldNM' :: NM c t a -> r
    foldNM' (Return a)   = ret a
    foldNM' (Bind tx k)  = bind tx (foldNM' . k)

lowerNM :: forall a c t. (a -> t a) -> (forall x. c x => t x -> (x -> t a) -> t a) -> NM c t a -> t a
lowerNM = foldNM

-------------------------------------------------------------------------------------------------

lowerSet :: Ord a => NM Unconstrained Set a -> Set a
lowerSet = lowerNM returnSet bindSet

s1 :: (c Char, c Int) => NM c Set (Int,Char)
s1 = do  n  <- liftNM (fromList [3,2,1,2])
         c  <- liftNM (fromList ['a','b'])
         return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet s1)

-------------------------------------------------------------------------------------------------

prettySet :: Show a => NM Show Set a -> String
prettySet = concat . foldNM returnShow bindSetShow

-------------------------------------------------------------------------------------------------

lowerVec :: Eq a => NM Finite Vec a -> Vec a
lowerVec = lowerNM returnVec bindVec

-------------------------------------------------------------------------------------------------

-- Example showing why "Deconstraining DSLs" is useful.

showFin :: NM FiniteShow Vec a -> String
showFin = foldNM (\ _ -> "") bindShowFin

-- does not type check
-- showAndLower :: Eq a => NM FiniteShow Vec a -> (String, Vec a)
-- showAndLower v = (showFin v, lowerNMVec v)

lowerVec' :: Eq a => NM FiniteShow Vec a -> Vec a
lowerVec' = foldNM returnVec bindVec

showAndLower' :: Eq a => NM FiniteShow Vec a -> (String, Vec a)
showAndLower' v = (showFin v, lowerVec' v)

-------------------------------------------------------------------------------------------------

data JS :: * -> * where
  Prompt :: JSString                 -> JS JSString
  Alert  :: JSString                 -> JS ()
  If     :: JSBool -> JSM a -> JSM a -> JS a

type JSM a = NM Sunroof JS a

compileJS :: Sunroof a => JS a -> CompM (JSCode,a)
compileJS (Prompt s)     = do (decl, v) <- newVar
                              return (concat [ decl, assignVar v ("prompt(" ++ showJS s ++ ")")], v)
compileJS (Alert s)      = return (concat [ "alert(", showJS s, ");" ], ())
compileJS (If b ja1 ja2) = do  (decl, v) <- newVar
                               (c1, a1)  <- compileJSM ja1
                               (c2, a2)  <- compileJSM ja2
                               return (concat  [ decl
                                               , "if(", showJS b, ") {"
                                               , c1, assignVar v $ showJS a1
                                               , "} else {"
                                               , c2, assignVar v $ showJS a2
                                               , "}" ], v)


compileJSM :: Sunroof a => JSM a -> CompM (JSCode,a)
compileJSM (Return a) = return ("",a)
compileJSM (Bind jx k) = do (c1,x) <- compileJS jx
                            (c2,a) <- compileJSM (k x)
                            return (c1 ++ c2, a)

prompt :: JSString -> JSM JSString
prompt = liftNM . Prompt

alert :: JSString -> JSM ()
alert = liftNM . Alert

js1 :: JSM ()
js1 = do reply <- prompt (string "Name?")
         alert (string "Hello: " <> reply)

-------------------------------------------------------------------------------------------------
