module PP where

pp :: String -> String
pp s = s ++ "\n"

indent :: Int -> [String] -> [String]
indent n = map (replicate n ' ' ++)


returnShow :: Show a => a -> [String]
returnShow = return . pp . ("Return " ++) . show
