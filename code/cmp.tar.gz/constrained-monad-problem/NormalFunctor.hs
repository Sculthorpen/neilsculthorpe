{-# LANGUAGE GADTs, KindSignatures, ConstraintKinds, RankNTypes, InstanceSigs #-}

module NormalFunctor where

import GHC.Exts (Constraint)

import Set
import ClassSynonyms

-------------------------------------------------------------------------------------------------

data NF :: (* -> Constraint) -> (* -> *) -> * -> * where
  FMap :: c x => (x -> a) -> t x -> NF c t a

-------------------------------------------------------------------------------------------------

liftNF :: c a => t a -> NF c t a
liftNF ta = FMap id ta    -- identity law

-------------------------------------------------------------------------------------------------

instance Functor (NF c t) where
  fmap :: (a -> b) -> NF c t a -> NF c t b
  fmap g (FMap h tx)  = FMap (g . h) tx  -- composition law

-------------------------------------------------------------------------------------------------

foldNF :: (forall x. c x => (x -> a) -> t x -> r) -> NF c t a -> r
foldNF fmp (FMap g tx) = fmp g tx

lowerNF :: (forall x. c x => (x -> a) -> t x -> t a) -> NF c t a -> t a
lowerNF  = foldNF

-------------------------------------------------------------------------------------------------

lowerSet :: Ord a => NF Unconstrained Set a -> Set a
lowerSet = lowerNF mapSet

s2 :: c Int => NF c Set Int
s2 = (+3) `fmap` (*2) `fmap` liftNF (fromList [1..5])

eg2 :: [Int]
eg2 = toList (lowerSet s2)

-------------------------------------------------------------------------------------------------
