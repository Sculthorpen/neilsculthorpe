{-# LANGUAGE FlexibleInstances, UndecidableInstances #-}

module Vector
 ( Vec(..),
   Finite(..),
   returnVec,
   bindVec,
   mapVec,
   bindShowFin,
   FiniteShow
 )
where

import Data.Complex

-------------------------------------------------------------------------------

class Finite a where
  enumerate :: [a]

newtype Vec a = V {unV :: a -> Complex Double}

returnVec :: Eq a => a -> Vec a
returnVec a = V (\ b -> if a == b then 1 else 0)

bindVec :: Finite a => Vec a -> (a -> Vec b) -> Vec b
bindVec (V v) k = V (\ b -> sum [ v a * unV (k a) b | a <- enumerate ] )

mapVec :: (Finite a, Eq b) => (a -> b) -> Vec a -> Vec b
mapVec f (V v) = V (\ b -> sum [ v a | a <- enumerate, f a == b ] )

-------------------------------------------------------------------------------

bindShowFin :: (Finite a, Show a) => Vec a -> (a -> String) -> String
bindShowFin _ k =  let as = enumerate
                   in show as ++ "\n" ++ concatMap k as

-------------------------------------------------------------------------------

class (Finite a, Show a) => FiniteShow a where
instance (Finite a, Show a) => FiniteShow a where

-------------------------------------------------------------------------------
