{-# LANGUAGE GADTs, KindSignatures, InstanceSigs #-}

module SetMonad where

import Set

-------------------------------------------------------------------------------------------------

data SetM :: * -> * where
  Return  :: a                       -> SetM a
  Bind    :: Set x -> (x -> SetM a)  -> SetM a

-------------------------------------------------------------------------------------------------

instance Monad SetM where
  return :: a -> SetM a
  return = Return

  (>>=) :: SetM a -> (a -> SetM b) -> SetM b
  (Return a)   >>= k  = k a                         -- left identity
  (Bind sx h)  >>= k  = Bind sx (\ x -> h x >>= k)  -- associativity

-------------------------------------------------------------------------------------------------

liftSet :: Set a -> SetM a
liftSet sa = Bind sa Return -- right identity

lowerSet :: Ord a => SetM a -> Set a
lowerSet (Return a)   = returnSet a
lowerSet (Bind sx k)  = bindSet sx (lowerSet . k)

-------------------------------------------------------------------------------------------------

s1 :: SetM (Int,Char)
s1 = do  n <- liftSet (fromList [3,2,1,2])
         c <- liftSet (fromList ['a','b'])
         return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet s1)

-------------------------------------------------------------------------------------------------
