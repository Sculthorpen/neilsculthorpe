{-# LANGUAGE GADTs, KindSignatures, ConstraintKinds, RankNTypes, InstanceSigs, ScopedTypeVariables #-}

module NormalMonadPlus where

import GHC.Exts (Constraint)
import Control.Monad

import Set
import ClassSynonyms

-------------------------------------------------------------------------------------------------

data NMP (c :: * -> Constraint) (t :: * -> *) (a :: *)
  =  MZero
  |  MPlus (NMP' c t a) (NMP c t a)

data NMP' :: (* -> Constraint) -> (* -> *) -> * -> * where
  Return  :: a                               -> NMP' c t a
  Bind    :: c x => t x -> (x -> NMP c t a)  -> NMP' c t a

-------------------------------------------------------------------------------------------------

toNMP :: NMP' c t a -> NMP c t a
toNMP n = MPlus n MZero -- right unit

liftNMP :: c a => t a -> NMP c t a
liftNMP ta = toNMP (Bind ta return) -- right identity

-------------------------------------------------------------------------------------------------

instance Monad (NMP c t) where
  return :: a -> NMP c t a
  return a = toNMP (Return a)

  (>>=) :: NMP c t a -> (a -> NMP c t b) -> NMP c t b
  MZero         >>= _  = MZero                             -- left zero
  MPlus n1 n2   >>= k  = mplus (bindNMP' n1 k) (n2 >>= k)  -- left distributivity

bindNMP' :: NMP' c t a -> (a -> NMP c t b) -> NMP c t b
bindNMP' (Return a)   k  = k a                                  -- left identity
bindNMP' (Bind tx h)  k  = toNMP (Bind tx (\ a -> h a >>= k))   -- associativity

instance MonadPlus (NMP c t) where
  mzero :: NMP c t a
  mzero = MZero

  mplus :: NMP c t a -> NMP c t a -> NMP c t a
  mplus MZero n            = n                       -- left unit
  mplus (MPlus n1 n2) n3   = MPlus n1 (mplus n2 n3)  -- associativity

-------------------------------------------------------------------------------------------------

foldNMP :: forall a c r t. r -> (r -> r -> r) -> (a -> r) -> (forall x. c x => t x -> (x -> r) -> r) -> NMP c t a -> r
foldNMP zero plus ret bind = foldNMPmonoid
  where
    foldNMPmonoid :: NMP c t a -> r
    foldNMPmonoid MZero          = zero
    foldNMPmonoid (MPlus n1 n2)  = plus (foldNMPmonad n1) (foldNMPmonoid n2)

    foldNMPmonad :: NMP' c t a -> r
    foldNMPmonad (Return a)   = ret a
    foldNMPmonad (Bind tx k)  = bind tx (foldNMPmonoid . k)

-------------------------------------------------------------------------------------------------

-- Set Example

lowerSet :: Ord a => NMP Unconstrained Set a -> Set a
lowerSet = foldNMP empty union returnSet bindSet

s1 :: c Int => NMP c Set (Int,Int)
s1 = do a <- liftNMP (fromList [4,3,2,1])
        b <- liftNMP (fromList [2,1,0])
        return (a,b) `mplus` return (7,7) `mplus` return (2,2)

eg1 :: [(Int,Int)]
eg1 = toList (lowerSet s1)

-------------------------------------------------------------------------------------------------
