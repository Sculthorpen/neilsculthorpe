{-# LANGUAGE FlexibleInstances #-}

module ClassSynonyms where

class Unconstrained a where
instance Unconstrained a where
