{-# LANGUAGE MultiParamTypeClasses, KindSignatures, ConstraintKinds, InstanceSigs, TypeFamilies #-}

module RestrictedTypeClasses where

import Prelude hiding (Functor,Monad)

import GHC.Exts (Constraint)

import ClassSynonyms

--------------------------------------------------------------------------------------

class RFunctor (c :: * -> Constraint) (f :: * -> *) where
  fmapR :: (c a, c b) => (a -> b) -> f a -> f b

class RFunctor c f => RApplicative (c :: * -> Constraint) (f :: * -> *) where
  pureR :: c a        => a -> f a
  apR   :: (c a, c b) => f (a -> b) -> f a -> f b

class RMonad (c :: * -> Constraint) (m :: * -> *) where
  returnR  :: c a        => a -> m a
  bindR    :: (c a, c b) => m a -> (a -> m b) -> m b

class RMonad c m => RMonadPlus (c :: * -> Constraint) (m :: * -> *) where
  mzeroR  :: c a => m a
  mplusR  :: c a => m a -> m a -> m a

--------------------------------------------------------------------------------------

class Functor (f :: * -> *) where
  type ConF f :: * -> Constraint
  type ConF f = Unconstrained

  fmap :: (ConF f a, ConF f b) => (a -> b) -> f a -> f b


class Functor f => Applicative (f :: * -> *) where
  type ConA f :: * -> Constraint
  type ConA f = Unconstrained

  pure  :: ConA f a             => a -> f a
  (<*>) :: (ConA f a, ConA f b) => f (a -> b) -> f a -> f b


class Monad (m :: * -> *) where
  type ConM m  ::  * -> Constraint
  type ConM m  =   Unconstrained

  return  :: ConM m a => a -> m a
  (>>=)   :: (ConM m a, ConM m b) => m a -> (a -> m b) -> m b


class Monad m => MonadPlus (m :: * -> *) where
  type ConMP m  ::  * -> Constraint
  type ConMP m  =   Unconstrained

  mzero  :: ConMP m a => m a
  mplus  :: ConMP m a => m a -> m a -> m a

--------------------------------------------------------------------------------------
