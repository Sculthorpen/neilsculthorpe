{-# LANGUAGE KindSignatures, GADTs, InstanceSigs #-}

module JSMonad where

import Sunroof

-----------------------------------------------------------------

data JS :: * -> * where
  Prompt :: JSString                 -> JS JSString
  Alert  :: JSString                 -> JS ()
  If     :: JSBool -> JSM a -> JSM a -> JS a

data JSM :: * -> * where
  Return :: a                                 -> JSM a
  Bind   :: Sunroof x => JS x -> (x -> JSM a) -> JSM a

-----------------------------------------------------------------

instance Monad JSM where
  return :: a -> JSM a
  return = Return

  (>>=) :: JSM a -> (a -> JSM b) -> JSM b
  (Return a)    >>= k  = k a                        -- left-identity law
  (ma `Bind` h) >>= k  = Bind ma (\a -> h a >>= k)  -- associativity law

-----------------------------------------------------------------

liftJS :: Sunroof a => JS a -> JSM a
liftJS x = Bind x Return -- right-identiy law

-----------------------------------------------------------------

compileJS :: Sunroof a => JS a -> CompM (JSCode,a)
compileJS (Prompt s)     = do (decl, v) <- newVar
                              return (concat [ decl, assignVar v ("prompt(" ++ showJS s ++ ")")], v)
compileJS (Alert s)      = return (concat [ "alert(", showJS s, ");" ], ())
compileJS (If b ja1 ja2) = do  (decl, v) <- newVar
                               (c1, a1)  <- compileJSM ja1
                               (c2, a2)  <- compileJSM ja2
                               return (concat  [ decl
                                               , "if(", showJS b, ") {"
                                               , c1, assignVar v $ showJS a1
                                               , "} else {"
                                               , c2, assignVar v $ showJS a2
                                               , "}" ], v)


compileJSM :: Sunroof a => JSM a -> CompM (JSCode,a)
compileJSM (Return a) = return ("",a)
compileJSM (Bind jx k) = do (c1,x) <- compileJS jx
                            (c2,a) <- compileJSM (k x)
                            return (c1 ++ c2, a)

-----------------------------------------------------------------

prompt :: JSString -> JSM JSString
prompt = liftJS . Prompt

alert :: JSString -> JSM ()
alert = liftJS . Alert

js1 :: JSM ()
js1 = do reply <- prompt (string "Name?")
         alert (string "Hello: " <> reply)

-----------------------------------------------------------------
