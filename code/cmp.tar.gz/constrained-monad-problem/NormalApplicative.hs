{-# LANGUAGE GADTs, KindSignatures, ConstraintKinds, RankNTypes, InstanceSigs, ScopedTypeVariables #-}

module NormalApplicative where

import GHC.Exts (Constraint)

import Control.Applicative

-------------------------------------------------------------------------------------------------

data NAF :: (* -> Constraint) -> (* -> *) -> * -> * where
  Pure   :: a                               -> NAF c t a
  Ap     :: c x => NAF c t (x -> a) -> t x  -> NAF c t a

-------------------------------------------------------------------------------------------------

instance Functor (NAF c t) where
  fmap :: (a -> b) -> NAF c t a -> NAF c t b
  fmap f n = pure f <*> n -- fmap law

instance Applicative (NAF c t) where
  pure :: a -> NAF c t a
  pure = Pure

  (<*>) :: NAF c t (a -> b) -> NAF c t a -> NAF c t b
  (Pure g) <*> (Pure a)  = Pure (g a)                  -- homomorphism law
  n1 <*> (Pure a)    = Pure (\ g -> g a) <*> n1        -- interchange law
  n1 <*> (Ap n2 tx)  = Ap (Pure (.) <*> n1 <*> n2) tx  -- composition law

-------------------------------------------------------------------------------------------------

liftNAF :: c a => t a -> NAF c t a
liftNAF ta = Ap (Pure id) ta  -- identity law

foldNAF :: forall a c r t. (forall x. x -> r x) -> (forall y z. c y => r (y -> z) -> t y -> r z) -> NAF c t a -> r a
foldNAF pur app = foldNAF'
  where
    foldNAF' :: forall b. NAF c t b -> r b
    foldNAF' (Pure b)   = pur b
    foldNAF' (Ap n tx)  = app (foldNAF' n) tx

lowerNAF :: (forall x. x -> t x) -> (forall y z. c y => t (y -> z) -> t y -> t z) -> NAF c t a -> t a
lowerNAF = foldNAF

-------------------------------------------------------------------------------------------------
