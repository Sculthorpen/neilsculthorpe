{-# LANGUAGE GADTs, MultiParamTypeClasses, FlexibleContexts, KindSignatures, DataKinds, InstanceSigs, ConstraintKinds, ScopedTypeVariables, RankNTypes #-}

module DeconstrainingDSLs where

import Elem

import Set
import Vector
import PP

-------------------------------------------------------

data NM :: [*] -> (* -> *) -> * -> * where
  Return  :: a                                     -> NM xs t a
  Bind    :: Elem x xs => t x -> (x -> NM xs t a)  -> NM xs t a

-------------------------------------------------------------------------------------------------

instance Monad (NM xs t) where
  return :: a -> NM xs t a
  return = Return

  (>>=) :: NM xs t a -> (a -> NM xs t b) -> NM xs t b
  (Return a)   >>= k  = k a                         -- left unit
  (Bind ta h)  >>= k  = Bind ta (\ a -> h a >>= k)  -- associativity

-------------------------------------------------------------------------------------------------

liftNM :: Elem a xs => t a -> NM xs t a
liftNM ta = Bind ta Return

foldNM :: forall a r t xs. (a -> r) -> (forall x. Elem x xs => t x -> (x -> r) -> r) -> NM xs t a -> r
foldNM ret bind = foldNM'
  where
    foldNM' :: NM xs t a -> r
    foldNM' (Return a)   = ret a
    foldNM' (Bind tx k)  = bind tx (foldNM' . k)

lowerNM :: forall a t xs. (a -> t a) -> (forall x. Elem x xs => t x -> (x -> t a) -> t a) -> NM xs t a -> t a
lowerNM = foldNM

-------------------------------------------------------------------------------------------------

lowerSet :: Ord a => NM xs Set a -> Set a
lowerSet = lowerNM returnSet bindSet

s1 ::  (Elem Int xs, Elem Char xs) => NM xs Set (Int,Char)
s1 = do  n <- liftNM (fromList [3,2,1,2])
         c <- liftNM (fromList ['a','b'])
         return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet (s1 :: NM '[Char,Int] Set (Int,Char)))

prettySet :: forall a xs. (Show a, All Show xs) => NM xs Set a -> String
prettySet = concat . foldNM returnShow
                            (\ (sx :: Set x) g -> case elemDict (Proxy :: Proxy xs) :: Dict (Show x) of
                                                      Dict -> bindSetShow sx g)

-------------------------------------------------------------------------------------------------

lowerVec :: forall a xs. (Eq a, All Finite xs) => NM xs Vec a -> Vec a
lowerVec = foldNM returnVec (\ (vx :: Vec x) k -> case elemDict (Proxy :: Proxy xs) :: Dict (Finite x) of
                                                      Dict -> bindVec vx k)

-------------------------------------------------------------------------------------------------

showFin :: forall a xs. (All Finite xs, All Show xs) => NM xs Vec a -> String
showFin = foldNM (\ _ -> "") (\ (vx :: Vec x) k -> case elemDict (Proxy :: Proxy xs) :: Dict (Finite x) of
                                                       Dict -> case elemDict (Proxy :: Proxy xs) :: Dict (Show x) of
                                                                 Dict -> bindShowFin vx k)

showAndLower :: (Eq a, All Finite xs, All Show xs) => NM xs Vec a -> (String, Vec a)
showAndLower v = (showFin v, lowerVec v)

-------------------------------------------------------------------------------------------------
