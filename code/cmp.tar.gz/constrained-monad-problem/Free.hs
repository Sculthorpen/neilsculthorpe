{-# LANGUAGE KindSignatures, InstanceSigs, RankNTypes #-}

module Free where

------------------------------------------------------------------

data Free (f :: * -> *) (a :: *) = Pure a | Impure (f (Free f a))

instance Functor f => Monad (Free f) where
  return :: a -> Free f a
  return = Pure

  (>>=) :: Free f a -> (a -> Free f b) -> Free f b
  (Pure a)      >>= k  = k a
  (Impure ffa)  >>= k  = Impure (fmap (>>= k) ffa)

liftFree :: (forall r. (a -> r) -> f a -> f r) -> f a -> Free f a
liftFree fmp fa = Impure (fmp Pure fa)

------------------------------------------------------------------
