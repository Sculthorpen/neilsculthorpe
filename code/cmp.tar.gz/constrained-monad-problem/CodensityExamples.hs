{-# LANGUAGE KindSignatures, GADTs #-}

module CodensityExamples where

import Set
import Vector
import Sunroof

import Codensity

-------------------------------------------------

liftSet :: Set a -> RCodT Ord Set a
liftSet = liftRCodT bindSet

lowerSet :: Ord a => RCodT Ord Set a -> Set a
lowerSet = lowerRCodT returnSet

s1 :: RCodT Ord Set (Int,Char)
s1 = do n <- liftSet (fromList [3,2,1,2])
        c <- liftSet (fromList ['a','b'])
        return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet s1)

-----------------------------

-- does not type check
-- liftCodTSet :: Set a -> CodT Set a
-- liftCodTSet = liftCodT bindSet

lowerCodTSet :: Ord a => CodT Set a -> Set a
lowerCodTSet = lowerCodT returnSet

-----------------------------

liftContTSet :: Ord r => Set a -> ContT r Set a
liftContTSet = liftContT bindSet

lowerContTSet :: Ord r => ContT r Set r -> Set r
lowerContTSet = lowerContT returnSet

s1' :: Ord r => ContT r Set (Int,Char)
s1' = do  n <- liftContTSet (fromList [3,2,1,2])
          c <- liftContTSet (fromList ['a','b'])
          return (n,c)

eg1' :: [(Int,Char)]
eg1' = toList (lowerContTSet s1')

-----------------------------

liftRYonedaSet :: Set a -> RYoneda Ord Set a
liftRYonedaSet = liftRYoneda mapSet

lowerRYonedaSet :: Ord a => RYoneda Ord Set a -> Set a
lowerRYonedaSet = lowerRYoneda

s2' :: RYoneda Ord Set Int
s2' = (+3) `fmap` (*2) `fmap` liftRYonedaSet (fromList [1..5])

eg2' :: [Int]
eg2' = toList (lowerRYonedaSet s2')

-------------------------------------------------

liftRCodTVec :: Finite a => Vec a -> RCodT Eq Vec a
liftRCodTVec = liftRCodT bindVec

lowerRCodTVec :: Eq a => RCodT Eq Vec a -> Vec a
lowerRCodTVec = lowerRCodT returnVec

-----------------------------

liftCodTVec :: Finite a => Vec a -> CodT Vec a
liftCodTVec = liftCodT bindVec

lowerCodTVec :: Eq a => CodT Vec a -> Vec a
lowerCodTVec = lowerCodT returnVec

-------------------------------------------------

data JS :: * -> * where
  Prompt :: JSString                 -> JS JSString
  Alert  :: JSString                 -> JS ()
  If     :: JSBool -> JSM a -> JSM a -> JS a

data JSM :: * -> * where
  Prim    :: JS a                                -> JSM a
  Bind    :: Sunroof x => JSM x -> (x -> JSM a)  -> JSM a
  Return  :: a                                   -> JSM a -- Only needed for lowering.

liftJSM :: Sunroof a => JSM a -> RCodT Sunroof JSM a
liftJSM = liftRCodT Bind

lowerJSM :: Sunroof a => RCodT Sunroof JSM a -> JSM a
lowerJSM = lowerRCodT Return

liftJS :: Sunroof a => JS a -> RCodT Sunroof JSM a
liftJS = liftJSM . Prim

compileJS :: Sunroof a => JS a -> CompM (JSCode,a)
compileJS (Prompt s)     = do (decl, v) <- newVar
                              return (concat [ decl, assignVar v ("prompt(" ++ showJS s ++ ")")], v)
compileJS (Alert s)      = return (concat [ "alert(", showJS s, ");" ], ())
compileJS (If b ja1 ja2) = do  (decl, v) <- newVar
                               (c1, a1)  <- compileJSM ja1
                               (c2, a2)  <- compileJSM ja2
                               return (concat  [ decl
                                               , "if(", showJS b, ") {"
                                               , c1, assignVar v $ showJS a1
                                               , "} else {"
                                               , c2, assignVar v $ showJS a2
                                               , "}" ], v)


compileJSM :: Sunroof a => JSM a -> CompM (JSCode,a)
compileJSM (Prim ja)   = compileJS ja
compileJSM (Return a)  = return ("",a)
compileJSM (Bind jx k) = do (c1,x) <- compileJSM jx
                            (c2,a) <- compileJSM (k x)
                            return (c1 ++ c2, a)

prompt :: JSString -> RCodT Sunroof JSM JSString
prompt = liftJS . Prompt

alert :: JSString -> RCodT Sunroof JSM ()
alert = liftJS . Alert

js1 :: RCodT Sunroof JSM ()
js1 = do reply <- prompt (string "Name?")
         alert (string "Hello: " <> reply)

-------------------------------------------------
