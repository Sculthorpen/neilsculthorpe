{-# LANGUAGE GADTs, MultiParamTypeClasses, FlexibleInstances, FlexibleContexts, TypeOperators, KindSignatures, PolyKinds, DataKinds, InstanceSigs, ConstraintKinds, ScopedTypeVariables, OverlappingInstances, UndecidableInstances, RankNTypes #-}

module Elem where

import GHC.Exts (Constraint)

-------------------------------------------------------

data ElemEvidence :: * -> [*] -> * where
  Head  ::               ElemEvidence a (a ': xs)
  Tail  :: Elem a xs =>  ElemEvidence a (b ': xs)

class Elem (a :: *) (as :: [*]) where
  evidence :: ElemEvidence a as

instance Elem a (a ': as) where
  evidence = Head

instance Elem a as => Elem a (b ': as) where
  evidence = Tail

-------------------------------------------------------

data Dict :: Constraint -> * where
  Dict :: con => Dict con

data Proxy (as :: [*]) = Proxy

-------------------------------------------------------

class All (c :: * -> Constraint) (as :: [*]) where
  elemDict :: Elem b as => Proxy as -> Dict (c b)

instance All c '[] where
--  elemDict :: forall b. Elem b '[] => Proxy '[] -> Dict (c b)
    elemDict _ = error "Elem b '[] : this can never occur."
                 -- case (evidence :: ElemEvidence a '[]) of

instance (c a, All c as) => All c (a ': as) where
  elemDict :: forall b. Elem b (a ': as) => Proxy (a ': as) -> Dict (c b)
  elemDict _ =  case evidence :: ElemEvidence b (a ': as) of
                  Head  -> Dict
                  Tail  -> elemDict (Proxy :: Proxy as)

-------------------------------------------------------
