module Set
 ( Set,
   empty,
   union,
   toList,
   fromList,
   mapSet,
   returnSet,
   bindSet,
   bindSetShow
 )
where

import Prelude
import Data.Set
import PP

-------------------------------------------------------------------------------------------------

returnSet :: a -> Set a
returnSet = singleton

bindSet :: Ord b => Set a -> (a -> Set b) -> Set b
bindSet sa k = unions (Prelude.map k (toList sa))

-- Requires package "containers 0.5.2.0" or higher to typecheck.
mapSet :: Ord b => (a -> b) -> Set a -> Set b
mapSet = Data.Set.map

-------------------------------------------------------------------------------------------------

bindSetShow :: Show a => Set a -> (a -> [String]) -> [String]
bindSetShow sa k = concat [ pp (show a) : indent 3 (k a) | a <- toList sa ]

-------------------------------------------------------------------------------------------------
