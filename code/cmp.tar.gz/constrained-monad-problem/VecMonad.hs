{-# LANGUAGE GADTs, KindSignatures, InstanceSigs #-}

module VecMonad where

import Vector

-------------------------------------------------------------------------------------------------

data VecM :: * -> * where
  Return  :: a                                   -> VecM a
  Bind    :: Finite x => Vec x -> (x -> VecM b)  -> VecM b

-------------------------------------------------------------------------------------------------

instance Monad VecM where
  return :: a -> VecM a
  return = Return

  (>>=) :: VecM a -> (a -> VecM b) -> VecM b
  (Return a)   >>= k  = k a                         -- left identity
  (Bind vx h)  >>= k  = Bind vx (\ x -> h x >>= k)  -- associativity

-------------------------------------------------------------------------------------------------

liftVecM :: Finite a => Vec a -> VecM a
liftVecM va = Bind va Return -- right identity

lowerVecM :: Eq a => VecM a -> Vec a
lowerVecM (Return a)   = returnVec a
lowerVecM (Bind vx k)  = bindVec vx (lowerVecM . k)

-------------------------------------------------------------------------------------------------
