{-# LANGUAGE RankNTypes, KindSignatures, GADTs, ConstraintKinds, ScopedTypeVariables #-}

import GHC.Exts (Constraint)

import Control.Monad.Prompt

import ClassSynonyms

import Set
import Vector

------------------------------------------------------------------

lowerPrompt :: (a -> t a) -> (forall x. t x -> (x -> t a) -> t a) -> Prompt t a -> t a
lowerPrompt = runPromptC

------------------------------------------------------------------

lowerSet :: Ord a => Prompt Set a -> Set a
lowerSet = lowerPrompt returnSet bindSet

s1 :: Prompt Set (Int,Char)
s1 = do  n <- prompt (fromList [3,2,1,2])
         c <- prompt (fromList ['a','b'])
         return (n,c)

eg1 :: [(Int,Char)]
eg1 = toList (lowerSet s1)

------------------------------------------------------------------

data FinVec :: * -> * where
  FV :: Finite a => Vec a -> FinVec a

lowerVec :: Eq a => Prompt FinVec a -> Vec a
lowerVec = runPromptC returnVec (\ (FV va) k -> bindVec va k)

------------------------------------------------------------------

data Box :: (* -> Constraint) -> (* -> *) -> * -> * where
  Box :: c a => t a -> Box c t a

unBox :: Box c t a -> t a
unBox (Box ta) = ta

------------------------------------------------------------------

liftBox :: c a => t a -> Prompt (Box c t) a
liftBox = prompt . Box

------------------------------------------------------------------

lowerBox :: c a => (a -> t a) -> (forall x. c x => t x -> (x -> t a) -> t a) -> Prompt (Box c t) a -> t a
lowerBox ret bind = runPromptC ret (\ (Box tx) k -> bind tx k)

------------------------------------------------------------------

lowerBoxSet :: Ord a => Prompt (Box Unconstrained Set) a -> Set a
lowerBoxSet = lowerBox returnSet bindSet

s1' :: (c Char, c Int) => Prompt (Box c Set) (Int,Char)
s1' = do  n <- liftBox (fromList [3,2,1,2])
          c <- liftBox (fromList ['a','b'])
          return (n,c)

eg1' :: [(Int,Char)]
eg1' = toList (lowerBoxSet s1')

------------------------------------------------------------------
