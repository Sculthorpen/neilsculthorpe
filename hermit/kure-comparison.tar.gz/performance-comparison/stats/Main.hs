{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE ViewPatterns #-}

module Main where

import LinReg (linearRegressionRSqr)

import System.Environment (getArgs)
import Data.List (nub,delete,sortBy)
import Data.Ord (comparing)
import Control.Applicative
import qualified Data.ByteString.Lazy as BL
import Data.Csv
import qualified Data.Vector as V
import qualified Data.Vector.Unboxed as U

import Data.List (tails)

logarithmicRegressionRSqr xs ys = linearRegressionRSqr xs (U.map log ys)

pad n s | d > 0 = s ++ replicate d ' '
        | otherwise = s
  where d = n - length s

banner s = do
  let w = maximum $ map length $ lines s
      bars = putStrLn $ replicate w '-'
  bars
  putStrLn s
  bars

data Bench
  = Bench
  { bLabel :: !String
  , bUniq :: !Int
  , bArg :: !Int
  , bMean,bMeanLB,bMeanUB,stddev,stddevLB,stddevUB :: !Double
  } deriving Show

instance FromNamedRecord Bench where
  parseNamedRecord r = mkBench
    <$> r .: "Name"
    <*> r .: "Mean"
    <*> r .: "MeanLB"
    <*> r .: "MeanUB"
    <*> r .: "Stddev"
    <*> r .: "StddevLB"
    <*> r .: "StddevUB"

mkBench s0 = Bench label uniq arg where
  (read -> uniq,_:s1) = break (==':') s0
  (read -> arg,_:s2) = break (=='/') s1
  label = s2

pLabel :: String -> String
pLabel = tail . dropWhile (/='/')

pArg :: String -> Int
pArg = read . takeWhile (/='/')



data Variant
  = Variant
  { vLabel :: !String
  , vBenches :: [Bench] -- INVARIANT: sorted by bArg
  }

data FitType = Linear | Log deriving (Show,Read)


main :: IO ()
main = do
    [filename,fitType,baseline,threshold] <- getArgs
    csvData <- BL.readFile filename
    case decodeByName csvData of
        Left err -> putStrLn err
        Right (_, bs) -> do
          let vs = separate baseline bs
          fits (< read threshold) (read fitType) vs
          geomeans vs
          pm_errs vs

separate :: String -> V.Vector Bench -> (Variant,[Variant])
separate baseline bs = (each baseline,map each (delete baseline labels)) where
  labels = nub $ map bLabel $ V.toList bs
  each lbl = Variant lbl $ sortBy (comparing bArg) $ filter ((==lbl) . bLabel) $ V.toList bs

width :: (Variant,[Variant]) -> Int
width (baseline,variants) = maximum $ map length labels where
  labels = map vLabel (baseline:variants)

dblWidth :: Int
dblWidth = 18

fits :: (Double -> Bool) -> FitType -> (Variant,[Variant]) -> IO ()
fits p fitType i@(baseline,variants) | any p rrs = banner hdr >> mapM_ (\(lbl,rr) -> putStr (pad (width i) lbl) >> putStr "   " >> print rr) (zip labels rrs)
                                   | otherwise = return () where
  hdr = "fits\n" ++ pad (width i) "Name" ++ "   " ++ pad dblWidth (show fitType ++ " r^2")
  vs = baseline:variants
  labels = map vLabel vs

  rrs = map each vs

  each Variant{vLabel=lbl,vBenches=these} = rr where
    xs = U.fromList $ map (toEnum . bArg) these
    ys = U.fromList $ map bMean these
    (yicept,slope,rr) = (\f -> f xs ys) $ case fitType of
      Linear -> linearRegressionRSqr
      Log    -> logarithmicRegressionRSqr

geomeans :: (Variant,[Variant]) -> IO ()
geomeans i@(baseline,variants) = banner hdr >> mapM_ each (baseline:variants) where
  hdr = "slowdowns\n" ++ pad (width i) "Name" ++ "   " ++ pad dblWidth "geoMean" ++ "   " ++ pad dblWidth "geoStdDev"

  baseline_means = map bMean $ vBenches baseline

  each Variant{vLabel=lbl,vBenches=these} = do
    putStr $ pad (width i) lbl
    putStr "   "
    putStr $ pad dblWidth $ show slowdown_geomean
    putStr "   "
    putStrLn $ pad dblWidth $ show slowdown_stddev
    where
      means = map bMean these
      n = length these
      slowdowns = zipWith (/) means baseline_means
      slowdown_geomean = product slowdowns ** recip (toEnum (length slowdowns))
      slowdown_stddev = exp $ sqrt $ (/ toEnum n) $ sum
        [ let x = log (sd / slowdown_geomean) in x * x | sd <- slowdowns ]

lowerTriangle :: [x] -> [(x,x)]
lowerTriangle [] = []
lowerTriangle xs@(_:ys) = concat $ zipWith (\x ys -> map ((,) x) ys) xs (tails ys)


-- For each unique benchmark invocation (eg fib argument, paradise
-- data structure, etc), for each pair of variants (eg KURE,
-- SYB-gmapM, etc), compute the percent error in the ratio of the two
-- measurements.  It only displays the average and maximum over all
-- benchmark invocations for each pair of variants.

pm_errs :: (Variant,[Variant]) -> IO ()
pm_errs i@(_,variants) = banner hdr >> mapM_ (uncurry each) (lowerTriangle variants) where
  dblWidth=22
  hdr = "Mean \"plus-minus\" error\n" ++ pad (2 * width i + 1) "Names" ++ "   " ++ pad dblWidth "-+ avg error %" ++ "   " ++ pad dblWidth "-+ max error %"

  each Variant{vLabel=lblL,vBenches=theseL} Variant{vLabel=lblR,vBenches=theseR} = do
      putStr $ pad (2 * width i + 1) (lblL ++ "/" ++ lblR)
      putStr "   "
      putStr $ pad dblWidth $ (++"%") $ show $ 100 * perr_geomean
      putStr "   "
      putStrLn $ pad dblWidth $ (++"%") $ show $ 100 * maximum perrs
    where
      mkPerr Bench{bMean=m,bMeanLB=lb,bMeanUB=ub} = (ub - lb) / m
-- (see below)      perrs = zipWith (\x y -> x * y + x - y) (map mkPerr theseL) (map mkPerr theseR)
      mkPerrs = zipWith (\x y -> let ub = bMeanUB x / bMeanLB y
                                     lb = bMeanLB x / bMeanUB y
                                     m  = bMean x / bMean y
                                 in (ub - lb) / m)

      -- this max doesn't seem to make a difference, but until I work
      -- through the math, this makes me more comfortable
      perrs = zipWith max (mkPerrs theseL theseR) (mkPerrs theseR theseL)
      perr_geomean = product perrs ** recip (toEnum (length perrs))



{-

THIS DIDN'T WORK -- why not?

Consider dividing two numbers that each have a plus or minus some % error.

  a -+ x%
  -------    =   a/b -+ z%
  b +- y%

The results have plus or minus z% error, where

z% =   x% * y%   +  x%  -  y%

Derivation:

The lowest possible value is:

  (1-x%)*a       1-x%
  --------   =   ----  * a/b
  (1+y%)*b       1+y%

so

1-x%
----   =   1-z%
1+y%

z% = 1 - (1-x%)/(1+y%)
z% = 1 - (1+y% - x%(1+y%))
z% = 1 - (1+y% - x% - x% * y%)

z% = -y% + x% + x% * y%

-}
