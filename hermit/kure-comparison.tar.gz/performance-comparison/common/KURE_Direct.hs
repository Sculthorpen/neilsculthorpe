{-# LANGUAGE RankNTypes #-}

-- some combinators for KURE like Uniplate's "Direct"

module KURE_Direct (ctor, leaf, child, inside,
                (|-), (|*), (||*), via, withCxt,
                direct_allR) where

import Language.KURE (Rewrite, apply, rewrite)
import Language.KURE.Injection

import Control.Monad (liftM, ap)



{-# INLINE ctor #-}
ctor f = \_ _ -> return f

{-# INLINE leaf #-}
leaf x f = \mh r -> ($ x) `liftM` f mh r

{-# INLINE child #-}
child x c f = inside x ($ c) f

{-# INLINE inside #-}
inside :: (Monad m, Injection b a, Monad n) =>
  t ->
  ((c -> b -> m b) -> t -> m x) ->
  ((forall a. m a -> n a) -> Rewrite c m a -> n (x -> y)) ->
  (forall a. m a -> n a) ->
  Rewrite c m a ->
  n y
inside x _mapM f = \mh r -> ap (f mh r) $ mh $ _mapM (\c -> ((>>= maybe (fail "projectM failed") return . project) . apply r c . inject) `asTypeOf` return) x

infixl 8 |-, ||*, |*

f |- x = leaf x f
f ||* (x,_mapM) = inside x _mapM f
f |* (x,c) = child x c f

{-# INLINE (|-) #-}
{-# INLINE (||*) #-}
{-# INLINE (|*) #-}

infix 9 `via`, `withCxt`

x `via` _mapM = (x, _mapM)
x `withCxt` c = (x, c)

{-# INLINE via #-}
{-# INLINE withCxt #-}

direct_allR :: (c -> a -> (forall a. m a -> m a) -> Rewrite c m a -> m a) ->
              Rewrite c m a -> Rewrite c m a
direct_allR x = \r -> rewrite $ \c a -> x c a id r

{-# INLINE direct_allR #-}
