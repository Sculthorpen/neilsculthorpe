module KURE_NoClass where

import Language.KURE
import Control.Arrow ((<<<),(>>>))

mk_allbuR allR r = prefixFailMsg "allbuR failed: " $
           let go = r <<< allR go
            in go
{-# INLINE mk_allbuR #-}

-- as expected, choice of <<< or >>> does not affect benchmarks
mk_allbuR2 allR r = prefixFailMsg "allbuR failed: " $
           let go = allR go >>> r
            in go
{-# INLINE mk_allbuR2 #-}
