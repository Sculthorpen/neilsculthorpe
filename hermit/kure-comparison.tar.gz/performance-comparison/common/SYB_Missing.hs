{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE ScopedTypeVariables #-}

-- If these are instead defined in the same module as they are used, I
-- see a slowdown. I suspect that GHC specializes to the monad "too
-- early", and this somehow inhibits further transformations.

module SYB_Missing (module SYB_Missing, module Data.Generics) where

import Data.Generics

everywhereMBut_sat :: forall m. Monad m =>
  GenericQ Bool -> GenericM m -> GenericM m
everywhereMBut_sat q f = w where
  w :: GenericM m
  w x | q x = return x
      | otherwise = gmapM w x >>= f
{-# INLINE everywhereMBut_sat #-}

-- everywhereM (ie above) after the static argument transform
everywhereM_sat :: forall m. Monad m => GenericM m -> GenericM m
everywhereM_sat f = go where
  go :: GenericM m
  go x = gmapM go x >>= f
