{-# LANGUAGE TemplateHaskell #-}

module TYB (reduce) where

import Common

import TYBAux

import Language.KURE.MonadCatch (runKureM, KureM)

import Control.Monad ((<=<))

reduce :: Fib -> Int
reduce = (runKureM id error .) $ unLitRule <=< ev where




  ev = fullBU (tryR $ plusRule <+ evfibR)


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)



(<+) f g = \a -> f a <<+ g a
tryR x = x <+ return



fullBU :: (Fib -> KureM Fib) -> Fib -> KureM Fib
fullBU f = $(everywhereForM 'f [t|Fib|])
