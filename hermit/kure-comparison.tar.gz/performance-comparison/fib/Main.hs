module Main where

import System.Environment (getEnv)

import qualified Common
import Common (Fib(..))
import qualified KURE
import qualified SYB
import qualified Uni
import qualified Hand

import Criterion.Config
import Criterion.Main (defaultMainWith, nf, bgroup, bench)

import Control.DeepSeq (rnf)
import System.Mem (performGC)


-- To benchmark on 20..25
--   Ns=`ghc -e [20..25]` ACTION=bench ./Test
--
-- To validate on 20..25
--   Ns=`ghc -e [20..25]` ACTION=validate ./Test
main = do
  nss <- getEnv "Ns"
  if null nss then putStrLn "The Ns environment variable must be a list of positive integers."
    else let ns :: [Int]
             ns = read nss
         in getEnv "ACTION" >>= \s -> case s of
              "validate" -> mainvalid ns
              "bench" -> rnf ns `seq` performGC >> mainbench ns
              _ -> putStrLn "ACTION must be in {validate,bench}"

run f i = f (Fib (Lit i))

variants =
  ("Hand", Hand.reduce) :
  ("KURE", KURE.reduce) :
  ("KURE-noclass", KURE.reduce_noclass) :
  ("SYB-gmapM", SYB.reduce) :
  ("SYB-sat", SYB.reduce_sat) :
  ("SYB-localsat", SYB.reduce_localsat) :
  ("SYB-sat-static", SYB.reduce_sat_static) :
  ("Uni", Uni.reduce) :
  []

mainvalid ns = print $ and
  [ run f i == run Common.eval i | i <- ns, f <- map snd variants ]

mainbench ns =
  let myConfig = defaultConfig
                 { cfgPerformGC = ljust True
                 , cfgSummaryFile = ljust $ "summary.csv"
                 , cfgSamples = ljust 10
                 }
  in rnf ns `seq` defaultMainWith myConfig (return ()) $ [
       bgroup (show n ++ ":" ++ show i)
         [ let x = if take 3 s == "SYB" && i > 31 then 0 else i
           in bench s $ nf (run reducer) x | (s, reducer) <- variants ]
      | (n,i) <- zip [0..] ns ]
