{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE FlexibleContexts #-}

module SYB (reduce, reduce_sat, reduce_localsat, reduce_sat_static) where

import Common

import Data.Generics
import SYBSYB

import SYB_Missing

import Language.KURE.MonadCatch (runKureM, KureM)

import Control.Monad ((<=<), MonadPlus(..))

reduce :: Fib -> Int
reduce = (runKureM id error .) $ unLitRule <=< ev where



  ev = everywhereM (mkM $ tryR $ plusRule <+ evfibR)


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)



(<+) f g = \a -> f a `mplus` g a
tryR x = x <+ return





reduce_sat :: Fib -> Int
reduce_sat = (runKureM id error .) $ unLitRule <=< ev where



  ev = everywhereM_sat (mkM $ tryR $ plusRule <+ evfibR)


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)



reduce_localsat :: Fib -> Int
reduce_localsat = (runKureM id error .) $ unLitRule <=< ev where


  ev = fullBU_sat (mkM $ tryR $ plusRule <+ evfibR)


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)

-- everywhereM after the static argument transform
fullBU_sat :: GenericM KureM -> GenericM KureM
fullBU_sat f = go where
  go :: GenericM KureM
  go x = gmapM go x >>= f





reduce_sat_static :: Fib -> Int
reduce_sat_static = (runKureM id error .) $ unLitRule <=< ev where



  ev = selectively $ fullBU_sat $ mkM $ tryR $ unselectively $ plusRule <+ evfibR


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)
