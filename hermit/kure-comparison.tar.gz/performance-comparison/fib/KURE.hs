{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE ImpredicativeTypes #-}

module KURE (reduce,reduce_noclass) where

import Common

import Control.Arrow ((<<<))

import Language.KURE
import KURE_NoClass
import KURE_Direct

-- the Injection a a instance suffices; it's a single-type traversal

instance Walker c Fib where
  allR = prim_allR
  {-# INLINE allR #-}

prim_allR :: Monad m => Rewrite c m Fib -> Rewrite c m Fib
prim_allR = direct_allR $ \c -> \case
  Plus a b -> ctor Plus |* a `withCxt` c |* b `withCxt` c
  Fib a -> ctor Fib |* a `withCxt` c
  x -> ctor x
{-# INLINE prim_allR #-}


reduce :: Fib -> Int
reduce = (runKureM id error .) $ flip apply () $ done <<< ev where

  done = contextfreeT unLitRule


  ev = allbuR (tryR $ plusBaseR <<+ evfibR)


  evfibR = fibBaseR <<+ (ev <<< fibStepR)


reduce_noclass :: Fib -> Int
reduce_noclass = (runKureM id error .) $ flip apply () $ done <<< ev where

  done = contextfreeT unLitRule


  ev = mk_allbuR prim_allR (tryR $ plusBaseR <<+ evfibR)


  evfibR = fibBaseR <<+ (ev <<< fibStepR)

plusBaseR = contextfreeT plusRule
fibBaseR  = contextfreeT fibBaseRule
fibStepR  = contextfreeT fibStepRule
