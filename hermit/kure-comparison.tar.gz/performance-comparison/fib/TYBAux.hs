{-# LANGUAGE TemplateHaskell #-}

module TYBAux (module Data.Generics.TH, everywhereForM, everywhereForM', everywhereButM) where

import Data.Generics.TH hiding (everywhereForM)
import qualified Data.Generics.TH
import Language.Haskell.TH.Syntax hiding (lift)
import Control.Monad (liftM)

everywhereForM' x = Data.Generics.TH.everywhereForM x

----------------------------------------
-- tweaked from TYB source to be bottom-up instead of top-down
everywhereForM :: (Quasi m)
  => Name -> (m Type -> m Exp)
everywhereForM func topTy = do
  everywhereButM (liftM not . inType (argTypeOfName func))
                  (const (return (VarE 'return)) `extE`
                   (eqType (argTypeOfName func), return (VarE func))) topTy

everywhereButM :: (Quasi m)
  => (Type -> m Bool) -> (Type -> m Exp) -> (m Type -> m Exp)
everywhereButM q f t0 = t0 >>= memoizeExp rec where
  rec k t = do q' <- q t
               if q' then return (VarE 'return)
                     else composeM (f t) (thmapM k (return t))


----------------------------------------
-- copied from TYB source
composeM :: (Quasi m) => m Exp -> m Exp -> m Exp
composeM f1 f2 = do
  f1' <- f1
  f2' <- f2
  x <- qNewName "x"
  return (LamE [VarP x] (InfixE (Just (AppE f2' (VarE x))) (VarE '(>>=)) (Just f1')))

argTypeOfName :: (Quasi m) => Name -> m Type
argTypeOfName n = do
  t <- typeOfName n
  let getArg (AppT (AppT ArrowT t') _) = return t'
      getArg (ForallT _ _ t') = getArg t'
      getArg _ = fail $ "'argTypeOfName' applied to `" ++ show n ++
                        " which has non-function type `" ++ show t ++ "'."
  getArg t