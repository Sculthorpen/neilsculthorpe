module Uni (reduce) where

import UniUni ()
import Data.Generics.Uniplate.Direct

import Common

import Language.KURE.MonadCatch (runKureM, KureM)

import Control.Monad ((<=<))



reduce :: Fib -> Int
reduce = (runKureM id error .) $ unLitRule <=< ev where




  ev = transformM (tryR $ plusRule <+ evfibR)


  evfibR = fibBaseRule <+ (ev <=< fibStepRule)



(<+) f g = \a -> f a <<+ g a
tryR x = x <+ return
