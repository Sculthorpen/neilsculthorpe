module UniUni () where

import Data.Generics.Uniplate.Direct

import Common

instance Uniplate Fib where
  uniplate (Plus a b) = plate Plus |* a |* b
  uniplate (Fib a) = plate Fib |* a
  uniplate x = plate x
  {-# INLINE uniplate #-}
