{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE FlexibleInstances #-}

module SYBSYB (Selective(..), selectively, unselectively) where

import Common

import Data.Generics

import Language.KURE.MonadCatch (KureM)

import Control.Monad



instance MonadPlus KureM where
  mzero = fail "mzero"
  mplus = (<<+)



deriving instance Typeable Fib

--deriving instance Data     Fib  -- about 15% slower than the explicit method definition
instance Data Fib where
  gmapM = \f ->
    let w (Lit i) = Lit `liftM` f i
        w (Plus a b) = Plus `liftM` f a `ap` f b
        w (Fib a) = Fib `liftM` f a
    in w
  {-# INLINE gmapM #-}






newtype Selective a = Selective {unSelective :: a} deriving (Show, Typeable)

instance Data (Selective Fib) where
  gmapM = \f ->
    let f' x = selectively f x -- NB the tempting eta contraction doesn't inline
        w x@Lit{} = return x
        w (Plus a b) = Plus `liftM` f' a `ap` f' b
        w (Fib a) = Fib `liftM` f' a
    in unselectively w
  {-# INLINE gmapM #-}

unselectively :: Monad m => (a -> m a) -> Selective a -> m (Selective a)
unselectively f = liftM Selective . f . unSelective
{-# INLINE unselectively #-}

selectively :: Monad m => (Selective a -> m (Selective a)) -> a -> m a
selectively f = liftM unSelective . f . Selective
{-# INLINE selectively #-}
