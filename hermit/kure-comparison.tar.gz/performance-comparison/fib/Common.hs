module Common where

import Language.KURE.MonadCatch (KureM, (<+))



data Fib = Lit Int | Plus Fib Fib | Fib Fib deriving Show


(<<+) x = (<+) x

-- semantics
eval :: Fib -> Int
eval (Lit i) = i
eval (Plus x y) = eval x + eval y
eval (Fib x) = case eval x of
  n -> case n of
    0 -> n
    1 -> n
    _ -> eval $ Fib (Lit $ n - 2) `Plus` Fib (Lit $ n - 1)


eval_old :: Fib -> Int
eval_old (Lit i) = i
eval_old (Plus x y) = eval x + eval y
eval_old (Fib (Lit 0)) = 0
eval_old (Fib (Lit 1)) = 1
eval_old (Fib n) = let n' = eval n in
  eval $ Fib (Lit $ n' - 2) `Plus` Fib (Lit $ n' - 1)



-- rules
plusRule :: Fib -> KureM Fib
plusRule (Plus (Lit x) (Lit y)) = return $ Lit $ x + y
plusRule _ = fail "plusRule"

fibBaseRule, fibStepRule :: Fib -> KureM Fib

fibBaseRule (Fib x@(Lit 0)) = return x
fibBaseRule (Fib x@(Lit 1)) = return x
fibBaseRule _ = fail "fibBaseRule"

fibStepRule (Fib n) = return $ Fib (n `Plus` Lit (-2)) `Plus`
                               Fib (n `Plus` Lit (-1))
fibStepRule _ = fail "fibStepRule"

unLitRule :: Fib -> KureM Int
unLitRule (Lit n) = return n
unLitRule _ = fail "unLitRule"
