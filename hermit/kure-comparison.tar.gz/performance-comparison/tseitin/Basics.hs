module Basics where

import Control.Monad.RWS.Strict

import Language.KURE.MonadCatch (KureM, (<+), MonadCatch(..), runKureM)


-- RWST's catchM abandons state updates by failed computations
instance (Monoid w,MonadCatch m) => MonadCatch (RWST r w s m) where
  catchM (RWST f) h = RWST $ \r s -> catchM (f r s) ((\x -> runRWST x r s) . h)


data Literal = Var String | TT | FF
  deriving (Eq,Show)

var :: String -> Prop
var = Lit . Var

data Prop
 = Lit Literal
 | And Prop Prop
 | Or Prop Prop
 | Not Prop
 deriving (Eq,Show)

type M = RWST () (Endo [[Prop]]) Int KureM

runM :: M a -> (a, [[Prop]])
runM x = fmap (flip appEndo []) $ runKureM id error $ evalRWST x () 0

gensym :: M String
gensym = do
  i <- get
  put $ i + 1
  return $ "$x" ++ show i

-- cf http://en.wikipedia.org/wiki/Tseitin_transformation

{-# INLINABLE andGate #-}
andGate :: Literal -> Literal -> M Literal
andGate al bl = gensym >>= f . Var where
  a = Lit al
  b = Lit bl
  f cl = tell (Endo $ (p1:) . (p2:) . (p3:)) >> return cl where
    c = Lit cl
    p1 = [Not a,Not b,c]
    p2 = [a,Not c]
    p3 = [b,Not c]

{-# INLINABLE orGate #-}
orGate :: Literal -> Literal -> M Literal
orGate al bl = gensym >>= f . Var where
  a = Lit al
  b = Lit bl
  f cl = tell (Endo $ (p1:) . (p2:) . (p3:)) >> return cl where
    c = Lit cl
    p1 = [a,b,c]
    p2 = [Not a,Not c]
    p3 = [Not b,Not c]

{-# INLINABLE notGate #-}
notGate :: Literal -> M Literal
notGate al = gensym >>= f . Var where
  a = Lit al
  f cl = tell (Endo $ ((p1:) . (p2:))) >> return cl where
    c = Lit cl
    p1 = [Not a,Not c]
    p2 = [a,c]



-- rules
andRule,orRule :: Prop -> M Prop

{-# INLINABLE andRule #-}
andRule (And (Lit a) (Lit b)) = Lit `liftM` andGate a b
andRule _ = fail "andRule"

{-# INLINABLE orRule #-}
orRule (Or (Lit a) (Lit b)) = Lit `liftM` orGate a b
orRule _ = fail "orRule"

{-# INLINABLE notRule #-}
notRule (Not (Lit a)) = Lit `liftM` notGate a
notRule _ = fail "notRule"
