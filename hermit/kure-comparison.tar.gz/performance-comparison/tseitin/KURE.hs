{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE ImpredicativeTypes #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module KURE (reduce,reduce_noclass,reduce_noclass2) where

import Basics

import Control.Category ((>>>))

import Language.KURE
import KURE_Direct
import KURE_NoClass



prim_allR :: Monad m => Rewrite c m Prop -> Rewrite c m Prop
prim_allR = direct_allR $ \c -> \case
  And a b -> ctor And |* a `withCxt` c |* b `withCxt` c
  Or a b -> ctor Or |* a `withCxt` c |* b `withCxt` c
  Not a -> ctor Not |* a `withCxt` c
  x -> ctor x
{-# INLINE prim_allR #-}


instance Walker c Prop where
  allR = prim_allR
  {-# INLINE allR #-}

reduce :: Prop -> (Prop,[[Prop]])
reduce = runM . apply ev () where

  ev :: Rewrite () M Prop
  ev = allbuR $ tryR $ andRuleR <<+ orRuleR <<+ notRuleR

reduce_noclass :: Prop -> (Prop,[[Prop]])
reduce_noclass = runM . apply ev () where

  ev :: Rewrite () M Prop
  ev = mk_allbuR prim_allR $ tryR $ andRuleR <<+ orRuleR <<+ notRuleR

reduce_noclass2 :: Prop -> (Prop,[[Prop]])
reduce_noclass2 = runM . apply ev () where

  ev :: Rewrite () M Prop
  ev = mk_allbuR2 prim_allR $ tryR $ andRuleR <<+ orRuleR <<+ notRuleR

andRuleR = contextfreeT andRule
orRuleR = contextfreeT orRule
notRuleR = contextfreeT notRule

(<<+) f g = f <+ g

