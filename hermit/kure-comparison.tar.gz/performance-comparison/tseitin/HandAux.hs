module HandAux where

import Basics

import Control.Monad (liftM,ap)

allR :: Monad m => (Prop -> m Prop) -> Prop -> m Prop
allR f (And a b) = And `liftM` f a `ap` f b
allR f (Or a b) = Or `liftM` f a `ap` f b
allR f (Not a) = Not `liftM` f a
allR _ x = return x

allbuR :: Monad m => (Prop -> m Prop) -> Prop -> m Prop
allbuR f = let go x = allR go x >>= f in go
