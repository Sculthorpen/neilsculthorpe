module Hand where

import HandAux

import Language.KURE.MonadCatch (runKureM, (<+))
import Basics

import Control.Monad (liftM,ap)



allR_local :: (Prop -> M Prop) -> Prop -> M Prop
allR_local f (And a b) = And `liftM` f a `ap` f b
allR_local f (Or a b) = Or `liftM` f a `ap` f b
allR_local f (Not a) = Not `liftM` f a
allR_local _ x = return x

allbuR_local :: (Prop -> M Prop) -> Prop -> M Prop
allbuR_local f = let go x = allR go x >>= f in go

allbuR_locallocal :: (Prop -> M Prop) -> Prop -> M Prop
allbuR_locallocal f = let go x = allR_local go x >>= f in go


reduce :: Prop -> (Prop,[[Prop]])
reduce = runM . tx where
  tx = allbuR $ tryR $ andRule <<+ orRule <<+ notRule


reduce_local :: Prop -> (Prop,[[Prop]])
reduce_local = runM . tx where
  tx = allbuR_local $ tryR $ andRule <<+ orRule <<+ notRule

reduce_locallocal :: Prop -> (Prop,[[Prop]])
reduce_locallocal = runM . tx where
  tx = allbuR_locallocal $ tryR $ andRule <<+ orRule <<+ notRule

(<<+) f g = \a -> f a <+ g a
tryR x = x <<+ return
