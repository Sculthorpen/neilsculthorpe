module Uni where

import Language.KURE.MonadCatch ((<+))
import Basics

import Data.Generics.Uniplate.Direct



instance Uniplate Prop where
  uniplate (And a b) = plate And |* a |* b
  uniplate (Or a b) = plate Or |* a |* b
  uniplate (Not a) = plate Not |* a
  uniplate x = plate x
  {-# INLINE uniplate #-}





reduce :: Prop -> (Prop,[[Prop]])
reduce = runM . tx where
  tx = transformM $ tryR $ andRule <<+ orRule <<+ notRule


(<<+) f g = \a -> f a <+ g a
tryR x = x <<+ return

