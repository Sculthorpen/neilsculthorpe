{-# LANGUAGE Rank2Types #-}
{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE FlexibleInstances #-}

module SYB (reduce, reduce_sat, reduce_sat_dyn_sel, reduce_static_sel, stopper) where

import Basics

import Data.Generics
import SYB_Missing

import Control.Monad

import Language.KURE.MonadCatch (runKureM, KureM, (<+))

import Control.Monad ((<=<), MonadPlus(..))



instance MonadPlus KureM where
  mzero = fail "mzero"
  mplus = (<+)



deriving instance Typeable Literal
deriving instance Typeable Prop



deriving instance Data Literal

-- deriving instance Data Prop -- goes about 15% slower; did not investigate why
instance Data Prop where
  gmapM = \f ->
    let w (Lit i) = Lit `liftM` f i
        w (And a b) = And `liftM` f a `ap` f b
        w (Or a b) = Or `liftM` f a `ap` f b
        w (Not a) = Not `liftM` f a
    in w
  {-# INLINE gmapM #-}










newtype Selective a = Selective {unSelective :: a} deriving (Show, Typeable)

instance Data (Selective Prop) where
  gmapM = \f ->
    let f' x = selectively f x -- NB the tempting eta contraction doesn't inline
        w x@Lit{} = return x
        w (And a b) = And `liftM` f' a `ap` f' b
        w (Or a b) = Or `liftM` f' a `ap` f' b
        w (Not a) = Not `liftM` f' a
    in unselectively w
  {-# INLINE gmapM #-}

unselectively :: Monad m => (a -> m a) -> Selective a -> m (Selective a)
unselectively f = liftM Selective . f . unSelective

selectively :: Monad m => (Selective a -> m (Selective a)) -> a -> m a
selectively f = liftM unSelective . f . Selective






reduce :: Prop -> (Prop,[[Prop]])
reduce = runM . tx where
  tx = everywhereM $ tryR $ andRule <<+ orRule <<+ notRule

(<<+) f g = \a -> f a `mplus` g a
tryR x = mkM x <<+ return





reduce_sat :: Prop -> (Prop,[[Prop]])
reduce_sat = runM . tx where
  tx = everywhereM_sat $ tryR $ andRule <<+ orRule <<+ notRule





reduce_sat_dyn_sel :: Prop -> (Prop,[[Prop]])
reduce_sat_dyn_sel = runM . tx where
  tx = everywhereMBut_sat stopper $ tryR $ andRule <<+ orRule <<+ notRule


stopper :: GenericQ Bool
stopper = mkQ False (const True :: Literal -> Bool)







reduce_static_sel :: Prop -> (Prop,[[Prop]])
reduce_static_sel = runM . tx where
  tx = selectively $ everywhereM_sat $ tryR $ unselectively $ andRule <<+ orRule <<+ notRule
