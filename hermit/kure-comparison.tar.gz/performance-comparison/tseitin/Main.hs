module Main where

import System.Environment (getEnv)

import qualified Basics
import Basics (Literal(..),Prop(..))
import qualified Hand
import qualified KURE
import qualified Uni
import qualified Data.Generics.Uniplate.Direct as Uni
import qualified SYB

import Criterion.Config
import Criterion.Main (defaultMainWith, nf, bgroup, bench)

import qualified Test.QuickCheck as QC
import Test.QuickCheck (Arbitrary(..))
import Test.QuickCheck.Gen (unGen)
import Test.QuickCheck.Random (mkQCGen)

import Control.Monad (liftM,ap)

import Control.DeepSeq (NFData(rnf))
import System.Mem (performGC)



instance NFData Literal where
  rnf (Var s) = rnf s
  rnf x = x `seq` ()
instance NFData Prop where
  rnf (And a b) = rnf a `seq` rnf b
  rnf (Or a b) = rnf a `seq` rnf b
  rnf (Not a) = rnf a
  rnf (Lit a) = rnf a

instance Arbitrary Literal where
  arbitrary = QC.frequency $
   [(10, QC.growingElements [ Var [c] | c <- ['a'..'z'] ])
   ,(1,return TT)
   ,(1,return FF)
   ]

instance Arbitrary Prop where
  arbitrary = QC.sized arbExp where
    arbExp n = QC.frequency $
      [(1,Lit `liftM` arbitrary)]
      ++ concat
      [ [(5,And `liftM` sub2 `ap` sub2)
        ,(5,Or `liftM` sub2 `ap` sub2)
        ,(3,Not `liftM` sub1)
        ]
      | n > 0
      ]
      where sub1 = arbExp (n - 1)
            sub2 = arbExp (n `div` 2)



mkcs :: Int -> [Prop]
mkcs n = take n $ filter ((>3000) . countNodes) $ unGen (sequence $ repeat arbitrary) (mkQCGen 280578) 7000


main = do
  n <- ((id :: Int -> Int) . read) `fmap` getEnv "N"
  let cs = mkcs n
  getEnv "ACTION" >>= \s -> case s of
    "validate" -> mainvalid cs
    "bench" -> rnf cs `seq` performGC >> mainbench cs
    "stats" -> mainstats cs
    _ -> putStrLn "ACTION must be in {validate,bench,stats}"

run f = f

variants =
  ("Hand", Hand.reduce) :
  ("Hand-local", Hand.reduce_local) :
  ("Hand-locallocal", Hand.reduce_locallocal) :
  ("KURE", KURE.reduce) :
  ("KURE-noclass", KURE.reduce_noclass) :
  ("SYB-gmapM", SYB.reduce) :
  ("SYB-sat", SYB.reduce_sat) :
  ("SYB-sat-dyn-sel", SYB.reduce_sat_dyn_sel) :
  ("SYB-sat-static-sel", SYB.reduce_static_sel) :
  ("Uni", Uni.reduce) :
  []

mainvalid cs = mapM_ (maybe (return ()) print) $
  [ if run f i == run Hand.reduce i then Nothing else Just (s, n)
      | (n, i) <- zip [0..] cs, (s, f) <- variants ]


mainbench cs =
  let myConfig = defaultConfig
                 { cfgPerformGC = ljust True
                 , cfgSummaryFile = ljust $ "summary.csv"
                 , cfgSamples = ljust 10
                 }
  in defaultMainWith myConfig (return ()) $ [
       bgroup (show n ++ ":" ++ show (countNodes c))
         [ bench s $ nf (run reducer) c | (s, reducer) <- variants ]
      | (n,c) <- zip [0..] cs ]

mainstats :: [Prop] -> IO ()
mainstats cs =
  mapM_ (\(i,x) -> let n = countNodes x
                       lits = countLits x
                       nots = countNots x
                   in putStrLn $ show i ++ "\t" ++ show n ++ "\tLit " ++ show (div' lits n) ++ "\tNot " ++ show (div' nots n)) $ zip [0..] cs

countNodes = length . Uni.universe
countLits x = length [ () | Basics.Lit _ <- Uni.universe x]
countNots x = length [ () | Basics.Not{} <- Uni.universe x]


div' :: Int -> Int -> Double
div' x y = toEnum x / toEnum y
