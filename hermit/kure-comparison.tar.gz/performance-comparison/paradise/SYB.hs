module SYB (increase, increase_sat, increase_sat_dyn_sel, stopper) where

import Common

import SYBSYB ()
import SYB_Missing

increase :: Integer -> Company -> Either String Company
increase k = (runKureM Right Left .) $
        everywhereM $
               mkM $ incS k

increase_sat :: Integer -> Company -> Either String Company
increase_sat k = (runKureM Right Left .) $
        everywhereM_sat $
               mkM $ incS k

increase_sat_dyn_sel :: Integer -> Company -> Either String Company
increase_sat_dyn_sel k = (runKureM Right Left .) $
        everywhereMBut_sat stopper  $
               mkM $ incS k

stopper :: GenericQ Bool
stopper = mkQ False (\P{} -> True) `extQ` (\x -> let _ = x `asTypeOf` "" in True)
