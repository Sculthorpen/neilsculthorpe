{-# LANGUAGE StandaloneDeriving #-}
{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE RankNTypes #-}

module SYBSYB (TgtSalary(..), TgtSalary_sat(..),
               gmapM_TgtSalary, gmapM_TgtSalary_sat) where

import Common

import Data.Generics

deriving instance Data Company
deriving instance Typeable Company
deriving instance Data Dept
deriving instance Typeable Dept
deriving instance Data Unit
deriving instance Typeable Unit
deriving instance Data Employee
deriving instance Typeable Employee
deriving instance Data Person
deriving instance Typeable Person
deriving instance Data Salary
deriving instance Typeable Salary


newtype TgtSalary a = TgtSalary {unTgtSalary :: a} deriving (Typeable)

wrap :: Monad m => (GenericM m -> a -> m a) -> GenericM m -> TgtSalary a -> m (TgtSalary a)
wrap mk f = liftM TgtSalary . mk f . unTgtSalary

gmapM_TgtSalary :: (Monad m, Data (TgtSalary a)) => GenericM m -> a -> m a
gmapM_TgtSalary f = liftM unTgtSalary . gmapM f . TgtSalary

instance Data (TgtSalary Company) where
  gmapM = wrap $ \f (C ds) -> C `liftM` mapM (gmapM_TgtSalary f) ds
  {-# INLINE gmapM #-}

instance Data (TgtSalary Dept) where
  gmapM = wrap $ \f (D n mgr us) ->
     D n `liftM` gmapM_TgtSalary f mgr `ap` mapM (gmapM_TgtSalary f) us
  {-# INLINE gmapM #-}

instance Data (TgtSalary Unit) where
  gmapM = wrap $ \f -> \case
    PU e -> PU `liftM` gmapM_TgtSalary f e
    DU d -> DU `liftM` gmapM_TgtSalary f d
  {-# INLINE gmapM #-}

instance Data (TgtSalary Employee) where
  gmapM = wrap $ \f (E p s) -> E p `liftM` f s
  {-# INLINE gmapM #-}

--------------------------------------------------------------------------------

newtype TgtSalary_sat a = TgtSalary_sat {unTgtSalary_sat :: a} deriving (Typeable)

wrap_sat :: Monad m => (GenericM m -> a -> m a) -> GenericM m -> TgtSalary_sat a -> m (TgtSalary_sat a)
wrap_sat mk f = liftM TgtSalary_sat . mk f . unTgtSalary_sat

gmapM_TgtSalary_sat :: (Monad m, Data (TgtSalary_sat a)) => GenericM m -> a -> m a
gmapM_TgtSalary_sat f = liftM unTgtSalary_sat . gmapM f . TgtSalary_sat

instance Data (TgtSalary_sat Company) where
  gmapM = wrap_sat $ \f (C ds) -> C `liftM` mapM (gmapM_TgtSalary_sat f) ds
  {-# INLINE gmapM #-}

instance Data (TgtSalary_sat Dept) where
  gmapM = wrap_sat $ \f ->
    -- explicit copy of the Unit dictionary to enable the static argument transform
    let copy_Unit = \case
          PU e -> PU `liftM` gmapM_TgtSalary_sat f e
          DU d -> DU `liftM` loop d
        {-# INLINE copy_Unit #-}
        loop = \(D n mgr us) -> D n `liftM` gmapM_TgtSalary_sat f mgr `ap` mapM copy_Unit us
    in loop
  {-# INLINE gmapM #-}

instance Data (TgtSalary_sat Unit) where
  gmapM = wrap_sat $ \f -> \case
    PU e -> PU `liftM` gmapM_TgtSalary_sat f e
    DU d -> DU `liftM` gmapM_TgtSalary_sat f d
  {-# INLINE gmapM #-}

instance Data (TgtSalary_sat Employee) where
  gmapM = wrap_sat $ \f (E p s) -> E p `liftM` f s
  {-# INLINE gmapM #-}
