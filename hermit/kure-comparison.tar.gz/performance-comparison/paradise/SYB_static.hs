{-# LANGUAGE FlexibleContexts #-}

module SYB_static (increase, increase_sat) where

import Common

import SYBSYB
import Data.Generics

increase :: Integer -> Company -> Either String Company
increase k = (runKureM Right Left .) $
        gmapM_TgtSalary $
               mkM $ incS k




increase_sat :: Integer -> Company -> Either String Company
increase_sat k = (runKureM Right Left .) $
        gmapM_TgtSalary_sat $
               mkM $ incS k
