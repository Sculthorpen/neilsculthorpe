{-# LANGUAGE ScopedTypeVariables #-}

module MyDyn where

import Data.Typeable.Internal
import GHC.Prim (Any)
import Unsafe.Coerce (unsafeCoerce)

data Dynamic = Dynamic !Fingerprint Any

fingerPrint (TypeRep fg _ _) = fg

toDyn :: Typeable a => a -> Dynamic
toDyn = \a -> Dynamic (fingerPrint $ typeOf a) (unsafeCoerce a)
{-# INLINE toDyn #-}

fromDyn :: forall a. Typeable a => Dynamic -> Maybe a
fromDyn = \(Dynamic k a) ->
  if (k ==) $ fingerPrint $ typeOf (undefined :: a) then
    Just (unsafeCoerce a)
  else Nothing
{-# INLINE fromDyn #-}
