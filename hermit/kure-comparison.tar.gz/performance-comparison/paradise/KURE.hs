module KURE (increase, increase_selective, increase_noclass) where

import Common

import KUREKURE (Tree,TgtEmployee,prim_allR)
import KURE_NoClass
import Language.KURE

increase :: Integer -> Company -> Either String Company
increase k = (runKureM Right Left .) $
             flip apply () $
             extractR $ (id :: Rewrite () KureM Tree -> Rewrite () KureM Tree) $
             allbuR $
             tryR $
             promoteR $
             contextfreeT $ \(E p s) -> E p `liftM` incS k s



increase_selective :: Integer -> Company -> Either String Company
increase_selective k = (runKureM Right Left .) $
             flip apply () $
             extractR $ (id :: Rewrite () KureM TgtEmployee -> Rewrite () KureM TgtEmployee) $
              allR
                                   $
             tryR $
             promoteR $
             contextfreeT $ \(E p s) -> E p `liftM` incS k s

increase_noclass :: Integer -> Company -> Either String Company
increase_noclass k = (runKureM Right Left .) $
             flip apply () $
             extractR $ (id :: Rewrite () KureM Tree -> Rewrite () KureM Tree) $
             mk_allbuR prim_allR $
             tryR $
             promoteR $
             contextfreeT $ \(E p s) -> E p `liftM` incS k s
