module Main where

import System.Environment (getEnv)

import qualified Common

import qualified KURE
import qualified KUREKURE as KURE
import qualified Language.KURE as KURE
import qualified KURE_Dyn
import qualified KURE_DynGADT
import qualified SYB
import qualified SYB_static
import qualified Uni
import qualified Data.Generics.Uniplate.Direct as Uni
import qualified Hand

import Data.Monoid (Sum(..))

import Criterion.Config
import Criterion.Main (defaultMainWith, nf, bgroup, bench)

import Test.QuickCheck (arbitrary)
import Test.QuickCheck.Gen (unGen)
import Test.QuickCheck.Random (mkQCGen)

import Control.DeepSeq (rnf)
import System.Mem (performGC)



mkcs n = take n $ filter ((>1000) . countNodes) $ unGen (sequence $ repeat arbitrary) (mkQCGen 280578) 70


main = do
  n <- ((id :: Int -> Int) . read) `fmap` getEnv "N"
  let cs = mkcs n
  getEnv "ACTION" >>= \s -> case s of
    "validate" -> mainvalid cs
    "bench" -> rnf cs `seq` performGC >> mainbench cs
    "stats" -> mainstats cs
    _ -> putStrLn "ACTION must be in {validate,bench,stats}"

run f = f 1

variants =
  ("Hand", Hand.increase) :
  ("Hand-sat", Hand.increase_sat) :
  ("KURE-noclass", KURE.increase_noclass) :
  ("KURE", KURE.increase) :
  ("KURE-sel", KURE.increase_selective) :
  ("KURE-Dyn", KURE_Dyn.increase) :
  ("KURE-DynGADT", KURE_DynGADT.increase) :
  ("SYB", SYB.increase) :
  ("SYB-sat", SYB.increase_sat) :
  ("SYB-sat-dyn-sel", SYB.increase_sat_dyn_sel) :
  ("SYB-static", SYB_static.increase) :
  ("SYB-static-sat", SYB_static.increase_sat) :
  ("Uni", Uni.increase) :
  []

mainvalid cs = mapM_ (maybe (return ()) print) $
  [ if run f i == run Hand.increase i then Nothing else Just (s, n)
      | (n, i) <- zip [0..] cs, (s, f) <- variants ]

mainbench cs =
  let myConfig = defaultConfig
                 { cfgPerformGC = ljust True
                 , cfgSummaryFile = ljust $ "summary.csv"
                 , cfgSamples = ljust 10
                 }
  in defaultMainWith myConfig (return ()) $ [
       bgroup (show n ++ ":" ++ show (countNodes c))
         [ bench s $ nf (run reducer) c | (s, reducer) <- variants ]
      | (n,c) <- zip [0..] cs ]

mainstats cs =
  mapM_ (\(i,x) -> let n = countNodes x
                       s = countSalaries x
                   in putStrLn $ show i ++ "\t" ++ show n ++ "\t" ++ show s ++ "\t" ++ show (div' s n)) $ zip [0..] cs

countSalaries :: Common.Company -> Int
countSalaries c = length (Uni.universeBi c :: [Common.Salary])

countNodes :: Common.Company -> Int
countNodes c = getSum $ KURE.fromKureM error $ KURE.applyT tx () (KURE.inject c :: KURE.Tree) where
  tx = KURE.foldbuT $ KURE.constT $ return $ Sum 1

div' :: Int -> Int -> Double
div' x y = toEnum x / toEnum y
