{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE Rank2Types, ScopedTypeVariables #-}
{-# LANGUAGE KindSignatures, GADTs, FlexibleContexts #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE ImpredicativeTypes #-}

module KUREKURE where

import Common

import KURE_Direct

import Language.KURE
import Language.KURE.Lens

import MyDyn
import Data.Typeable (Typeable)
import SYBSYB ()

import Data.Monoid

data Tree
  = C' !Company
  | D' !Dept
  | U' !Unit
  | E' !Employee
  | P' !Person

instance Injection Company Tree where
  inject = C'
  project (C' x) = Just x
  project _ = Nothing

instance Injection Dept Tree where
  inject = D'
  project (D' x) = Just x
  project _ = Nothing

instance Injection Unit Tree where
  inject = U'
  project (U' x) = Just x
  project _ = Nothing

instance Injection Employee Tree where
  inject = E'
  project (E' x) = Just x
  project _ = Nothing

instance Injection Person Tree where
  inject = P'
  project (P' x) = Just x
  project _ = Nothing

--------------------------------------------------------------------------------
-- allR

prim_allR :: Monad m => Rewrite c m Tree -> Rewrite c m Tree
prim_allR = direct_allR $ \c -> \case
    C' (C ds) -> ctor (C' . C) ||* ds `via` \f -> mapM (f c)
    D' (D nm m us) ->
      ctor (\nm m us -> D' $ D nm m us) |- nm |* m `withCxt` c ||* us `via` \f -> mapM (f c)
    U' (PU e) -> ctor (U' . PU) |* e `withCxt` c
    U' (DU u) -> ctor (U' . DU) |* u `withCxt` c
    E' (E p s) -> ctor (E' . flip E s) |* p `withCxt` c
    x -> ctor x
{-# INLINE prim_allR #-}

instance Walker c Tree where
  allR = prim_allR
  {-# INLINE allR #-}

--------------------------------------------------------------------------------
-- allR via Dynamic

newtype TreeDyn = TreeDyn Dynamic
instance Typeable a => Injection a TreeDyn where
  inject = TreeDyn . toDyn
  project (TreeDyn x) = fromDyn x

infixl `ext`
ext :: Typeable a => (TreeDyn -> m TreeDyn) -> (a -> m TreeDyn) -> TreeDyn -> m TreeDyn
ext g f x@(TreeDyn y) = maybe (g x) f (fromDyn y)

prim_allR_Dyn :: forall c m. Monad m => Rewrite c m TreeDyn -> Rewrite c m TreeDyn
prim_allR_Dyn g = rewrite $ \c -> return `ext`
  (\(C ds) -> (inject . C) `liftM` mapM (gapply c) ds) `ext`
  (\(D nm m us) ->
    (\m us -> inject $ D nm m us) `liftM` gapply c m `ap` mapM (gapply c) us) `ext`
  (\case
    (PU e) -> (inject . PU) `liftM` gapply c e
    (DU u) -> (inject . DU) `liftM` gapply c u) `ext`
  (\(E p s) -> (inject . flip E s) `liftM` gapply c p)
  where gapply :: forall a. (Monad m, Typeable a) => c -> a -> m a
        gapply c a = apply g c (TreeDyn $ toDyn a) >>=
                     maybe (fail "projectM") return . (\(TreeDyn x) -> fromDyn x)
        {-# INLINE gapply #-}
{-# INLINE prim_allR_Dyn #-}

instance Walker c TreeDyn where
  allR = prim_allR_Dyn
  {-# INLINE allR #-}

--------------------------------------------------------------------------------
-- allR via a GADT-based Dynamic

data TreeGADT :: * -> * where
  TreeC :: TreeGADT Company
  TreeD :: TreeGADT Dept
  TreeU :: TreeGADT Unit
  TreeE :: TreeGADT Employee
  TreeP :: TreeGADT Person

data TreeDynGADT = forall a. TreeDynGADT !(TreeGADT a) !a

instance Injection Company TreeDynGADT where
  inject = TreeDynGADT TreeC
  project (TreeDynGADT TreeC x) = Just x
  project _ = Nothing

instance Injection Dept TreeDynGADT where
  inject = TreeDynGADT TreeD
  project (TreeDynGADT TreeD x) = Just x
  project _ = Nothing

instance Injection Unit TreeDynGADT where
  inject = TreeDynGADT TreeU
  project (TreeDynGADT TreeU x) = Just x
  project _ = Nothing

instance Injection Employee TreeDynGADT where
  inject = TreeDynGADT TreeE
  project (TreeDynGADT TreeE x) = Just x
  project _ = Nothing

instance Injection Person TreeDynGADT where
  inject = TreeDynGADT TreeP
  project (TreeDynGADT TreeP x) = Just x
  project _ = Nothing

prim_allR_DynGADT :: forall c m. Monad m => Rewrite c m TreeDynGADT -> Rewrite c m TreeDynGADT
prim_allR_DynGADT g = rewrite $ \c x -> case x of
  TreeDynGADT TreeC (C ds) -> (inject . C) `liftM` mapM (gapply c) ds
  TreeDynGADT TreeD (D nm m us) -> (\m us -> inject $ D nm m us) `liftM` gapply c m `ap` mapM (gapply c) us
  TreeDynGADT TreeU x -> case x of
    (PU e) -> (inject . PU) `liftM` gapply c e
    (DU u) -> (inject . DU) `liftM` gapply c u
  TreeDynGADT TreeE (E p s) -> (inject . flip E s) `liftM` gapply c p
  _ -> return x
  where gapply :: forall a. (Monad m, Injection a TreeDynGADT) => c -> a -> m a
        gapply c = projectM <=< apply g c . inject
        {-# INLINE gapply #-}
{-# INLINE prim_allR_DynGADT #-}

instance Walker c TreeDynGADT where
  allR = prim_allR_DynGADT
  {-# INLINE allR #-}

--------------------------------------------------------------------------------
-- current KURE, selective for Employee

newtype TgtEmployee = TgtEmployee {unTgtEmployee :: Tree}

instance Injection a Tree => Injection a TgtEmployee where
  inject = TgtEmployee . inject
  project = project . unTgtEmployee

instance Walker c TgtEmployee where
  allR r = rewrite $ \c -> (liftM TgtEmployee .) $ (. unTgtEmployee) $
    let
      wC (C ds) = C `liftM` mapM wD ds
      wD (D nm mgr us) = D nm `liftM` wE mgr `ap` mapM wU us
      wU (PU e) = PU `liftM` wE e
      wU (DU d) = DU `liftM` wD d
      wE e = apply (extractR r) c e
    in \case
      C' x -> C' `liftM` wC x
      D' x -> D' `liftM` wD x
      U' x -> U' `liftM` wU x
      x -> return x
  {-# INLINE allR #-}
