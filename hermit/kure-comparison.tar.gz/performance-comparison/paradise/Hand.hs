module Hand (increase, increase_sat) where

import HandHand

import Common

increase :: Integer -> Company -> Either String Company
increase k = (runKureM Right Left .) $
                 allbuR_C_S (incS k)


increase_sat :: Integer -> Company -> Either String Company
increase_sat k = (runKureM Right Left .) $
                (_sat_C . allbuR_S_sat) (incS k)
