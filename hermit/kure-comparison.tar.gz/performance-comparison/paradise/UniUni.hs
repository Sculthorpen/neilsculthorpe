{-# LANGUAGE MultiParamTypeClasses #-}

module UniUni () where

import Common

import Data.Generics.Uniplate.Direct



instance Biplate Company Salary where
  biplate (C x1) = plate C ||+ x1
  {-# INLINE biplate #-}

instance Biplate Dept Salary where
  biplate (D x1 x2 x3) = plate (D x1) |+ x2 ||+ x3
  {-# INLINE biplate #-}

instance Biplate Employee Salary where
  biplate (E x1 x2) = plate (E x1) |* x2
  {-# INLINE biplate #-}

instance Biplate Unit Salary where
  biplate (PU x1) = plate PU |+ x1
  biplate (DU x1) = plate DU |+ x1
  {-# INLINE biplate #-}

instance Biplate Person Salary where
  biplate x = plate x
  {-# INLINE biplate #-}

instance Biplate Salary Salary where
  biplate = plateSelf
  {-# INLINE biplate #-}

instance Uniplate Salary where
  uniplate = plate
  {-# INLINE uniplate #-}
