module KURE_DynGADT (increase) where

import Common

import KUREKURE
import Language.KURE

increase :: Integer -> Company -> Either String Company
increase k = (runKureM Right Left .) $
             flip apply () $
             extractR $ (id :: Rewrite c m TreeDynGADT -> Rewrite c m TreeDynGADT) $
             allbuR $
             tryR $
             promoteR $
             contextfreeT $ \(E p s) -> E p `liftM` incS k s
