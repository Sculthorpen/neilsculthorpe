module MapFusion where

import Prelude hiding (map)

-- For 7.6 compatibility.
import GHC.Err (undefined)

{-# RULES "map-fusion" forall f g.  map f . map g = map (f . g)  #-}

map :: (a -> b) -> [a] -> [b]
map f []     = []
map f (a:as) = f a : map f as
