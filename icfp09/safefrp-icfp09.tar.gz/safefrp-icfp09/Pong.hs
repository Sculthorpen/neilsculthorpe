module Pong where

import Balls
import Library
import Primitives

-------------------------------------------------------------------------------

type XCo       =  Distance
type YCo       =  Distance
type Co        =  (XCo, YCo)
type BallPos   =  Co
type PaddlePos =  XCo
type BallVel   =  Velocity

data PaddleMovement = Forewards | Stop | Backwards

data PaddleModel = PaddleModel {ppos :: PaddlePos, pmove :: PaddleMovement}

data BallModel = BallModel {xpos :: XCo, xvel :: Velocity, ypos :: YCo, yvel :: Velocity}

data PongView = PongView BallPos PaddlePos

data PaddleEdge = LeftEdge | Middle | RightEdge
data PaddleBounce = Hit PaddleMovement PaddleEdge | Miss


paddleSpeed = 15
paddleMomentum = paddleSpeed / 10 -- momentum transferred to ball upon bounce

paddleSize  = 10
ballRadius  = 1.2
wind = 3
binit = BallModel{xpos = 70, xvel = -20, ypos = 50, yvel = 20}
pinit = 45

yOut     = -5
rwallPos = 60

bpos   :: BallModel -> BallPos
bpos b =  (xpos b, ypos b)


paddleVel :: PaddleMovement -> Velocity
paddleVel Forewards = paddleSpeed
paddleVel Backwards = -paddleSpeed
paddleVel Stop      = 0

adjustPMforWall :: PaddleMovement -> PaddlePos -> PaddleMovement
adjustPMforWall Forewards x | x + paddleSize >= rwallPos = Stop
adjustPMforWall Backwards x | x <= 0                     = Stop
adjustPMforWall pm        _                              = pm

isBounce :: PaddleBounce -> Bool
isBounce Miss      = False
isBounce (Hit _ _) = True

bounceType :: XCo -> PaddleModel -> PaddleBounce
bounceType x pm  |  x + z > pl && x - z < pr  =  Hit (pmove pm) padEdge 
                 | otherwise                  =  Miss
  where
    pl = ppos pm
    pr = pl + paddleSize
    z  = ballRadius
    padEdge | x < pl    = LeftEdge
            | x > pr    = RightEdge
            | otherwise = Middle 

-- applyBounce :: PaddleBounce -> BallModel -> BallModel
-- applyBounce (Hit pmove pedge) (BallModel x xvel y yvel) = BallModel x xvel' y (-yvel)
--   where
--     xvel' = paddleVel pmove * paddleMomentum + edgeEffect

--     edgeEffect :: Velocity
--     edgeEffect =  case pedge of
--                     Middle    -> xvel
--                     LeftEdge  -> (if xvel > 0 then -xvel else xvel)
--                     RightEdge -> (if xvel < 0 then -xvel else xvel)



applyBounce :: PaddleBounce -> BallModel -> BallModel
applyBounce (Hit pmove pedge) (BallModel x xvel y yvel) = BallModel x xvel' y yvel'
  where
    xvel' = paddleVel pmove * paddleMomentum + fst edgeEffect
    yvel' = snd edgeEffect

    edgeEffect :: (Velocity, Velocity)
    edgeEffect =  case pedge of
                    Middle    -> (xvel, -yvel)
                    LeftEdge  -> ((if xvel > 0 then -partialX else xvel + partialX), partialBounceY)
                    RightEdge -> ((if xvel < 0 then -partialX else xvel + partialX), partialBounceY)

    partialBounceY = yvel * (-(2/3))
    partialX       = xvel * 2/3



paddleGlide   :: PaddlePos -> SF (C PaddleMovement) (C PaddlePos) Cau
paddleGlide p =  lift paddleVel >>>> iIntegral p

paddleMove   :: PaddlePos -> SF (C PaddleMovement) (C PaddlePos) Cau
paddleMove p =  sfLoop (lift2 adjustPMforWall >>>> paddleGlide p >>>> sfFork) (iPre p)

paddle    :: PaddlePos -> SF (E PaddleMovement) (C PaddleModel) Cau
paddle p  =  hold Stop >>>> paddleMove p &&&& identity >>>> lift2 PaddleModel


xbouncer :: Velocity -> XCo -> SF as (C XCo, C Velocity) Dec
xbouncer =  doubleBouncer ballRadius (rwallPos - ballRadius) (negate wind)


detectBallLand :: SF (C BallModel) (E XCo) Cau
detectBallLand =  (lift ypos &&&& lift yvel >>>> detectBounce (floorBounce ballRadius)) &&&& lift xpos >>>> sample 

filterPaddleBounce :: SF (E XCo, C PaddleModel) (E PaddleBounce) Cau
filterPaddleBounce =  lift2 bounceType >>>> filterE isBounce

detectPaddleBounce :: SF (C BallModel, C PaddleModel) (E PaddleBounce) Cau
detectPaddleBounce =  sfFirst detectBallLand >>>> filterPaddleBounce


ballFreeFlight :: BallModel -> SF as (C BallModel) Dec
ballFreeFlight (BallModel x xvel y yvel)  =  xbouncer xvel x &&&& falling yvel y >>>> lift4 BallModel

ballFlight :: BallModel -> SF (C PaddleModel) (E (PaddleBounce, BallModel), C BallModel) Cau
ballFlight b   =  ballFreeFlight b &&&& identity >>>> detectPaddleBounce &&&& sfFst >>>> lift2 (,) &&&& sfSnd

bounceOnPaddle :: PaddleBounce -> BallModel -> SF (C PaddleModel) (E (PaddleBounce, BallModel), C BallModel) Cau
bounceOnPaddle pm b =  ballFlight (applyBounce pm b)


ball :: BallModel -> SF (C PaddleModel) (C BallPos) Cau
ball b  =  nrswitch Cau (ballFlight b) (uncurry bounceOnPaddle) >>>> lift bpos

newBall :: SF (C PaddleModel) (C BallPos) Cau
newBall =  ball binit


detectLostBall :: SF (C BallPos) (E ()) Dec
detectLostBall =  dedgeWhen ((< yOut).snd)

recycleBall :: SF (E (), C PaddleModel) (C BallPos) Cau
recycleBall =  sfFirst (tag newBall) >>>> rswitch newBall 

balls :: SF (C PaddleModel) (C BallPos) Cau
balls =  sfLoop (sfSwap >>>> recycleBall >>>> sfFork) detectLostBall 

pongAux :: PaddlePos -> SF (E PaddleMovement) (C PongView) Cau
pongAux p = paddle p >>>> balls &&&& lift ppos >>>> lift2 PongView

pong :: SF (E PaddleMovement) (C PongView) Cau
pong =  pongAux pinit
