module Reactimator where

import Utilities
import Control.Arrow
import Control.Monad

import Core
import Evaluator

-----------------------------------------------------------------------------


reactimate :: IO (Time, SRep as) -> (SRep bs -> IO Bool) -> SF as bs d -> IO ()
reactimate input output sf = do (t, as) <- input
                                let (sf', bs) = runSF t sf as
                                done <- output bs
                                if done
                                 then return ()
                                 else reactimate input output sf'


reactimateCC :: IO (Time, a) -> (b -> IO Bool) -> SF (C a) (C b) d -> IO ()
reactimateCC input output = reactimate ((liftM.second) C input) (argument unC output)

reactimateEE :: IO (Time, Maybe a) -> (Maybe b -> IO Bool) -> SF (E a) (E b) d -> IO ()
reactimateEE input output = reactimate ((liftM.second) E input) (argument unE output)

reactimateCE :: IO (Time, a) -> (Maybe b -> IO Bool) -> SF (C a) (E b) d -> IO ()
reactimateCE input output = reactimate ((liftM.second) C input) (argument unE output)

reactimateEC :: IO (Time, Maybe a) -> (b -> IO Bool) -> SF (E a) (C b) d -> IO ()
reactimateEC input output = reactimate ((liftM.second) E input) (argument unC output)
