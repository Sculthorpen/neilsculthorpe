{-# LANGUAGE GADTs #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Evaluator where

import Utilities
import Control.Arrow

import Decoupled
import Core


-----------------------------------------------------------------------------------------

weakenSw :: DRep d1 -> SF0 as bs d2 -> SF0 as bs (d1 :**: d2)
weakenSw Dec = id
weakenSw Cau = Weaken


weakenDRSw :: DRep d2 -> DRep d1 -> SF0 as bs (d2 :**: d2) -> SF0 as bs (d1 :**: d2)
weakenDRSw Dec = weakenSw
weakenDRSw Cau = weakenSw

-----------------------------------------------------------------------------------------

eval :: forall as bs d. Dt -> SF0 as bs d -> SRep as -> (SF0 as bs d, SRep bs)

eval t (Constant bs) as = (Constant bs , bs)

eval t Identity as = (Identity , as)

eval t (Prim f s) as = first (Prim f) (f t s as)

eval t (DPrim f s) as = first (DPrim f . applyTo as) (f t s)

eval t (Weaken sf) as = first Weaken (eval t sf as)

eval t (Seq d1 sf1 sf2) as = (Seq d1 sf1' sf2', cs)
                                where 
                                      (sf1' , bs) = eval t sf1 as
                                      (sf2' , cs) = eval t sf2 bs

eval t (Fan d1 sf1 sf2) as = pairZipWiths (Fan d1) (:::) (eval t sf1 as) (eval t sf2 as)

eval t (Fst sf) (as ::: _) = first Fst (eval t sf as)

eval t (Snd sf) (_ ::: bs) = first Snd (eval t sf bs)

eval t (Switch d sf f) as  = case eval t sf as of
                                (sf' , (E Nothing  ::: bs))  ->  (Switch d sf' f , bs)
                                (_   , (E (Just e) ::: _ ))  ->  first (weakenSw d) (eval 0 (f e) as)

eval t (DKSwitch d sf sfe f) as = (newSF, bs)
                                  where
                                        (sf', bs) = eval t sf as

                                        newSF     :: SF0 as bs d
                                        newSF     =  case eval t sfe (as ::: bs) of
                                                       (sfe', E Nothing )  ->  DKSwitch d sf' sfe' f
                                                       (sfe', E (Just e))  ->  (weakenSw d . fst) (eval 0 (f sf' e) as)

eval t (Loop sfs sff) as = let (ff, cs) = evalDec t sff
                            in case eval t sfs (as ::: cs) of
                                 (sfs', bs ::: ds) -> (Loop sfs' (ff ds) , bs)

eval t (Snapshot d sf) as = let (sf', bs) = eval t sf as
                             in (Snapshot d sf', C (SF d sf') ::: bs)

-----------------------------------------------------------------------------------------


evalDec :: forall as bs. Dt -> SF0 as bs Dec -> ((SRep as -> SF0 as bs Dec) , SRep bs)

evalDec t (Constant bs) = (const (Constant bs) , bs) 

evalDec t (DPrim f s) = (first.result) (DPrim f) (f t s)

evalDec t (Seq Cau sf1 sf2) = first (\ f2 -> uncurry (Seq Cau) . second f2 . eval t sf1) (evalDec t sf2)
evalDec t (Seq Dec sf1 sf2) = let
                                  (f1  , xs) = evalDec t sf1
                                  (sf2', bs) = eval t sf2 xs
                               in
                                  (\ as -> Seq Dec (f1 as) sf2', bs)

evalDec t (Fan Dec sf1 sf2) = pairZipWiths (\ g1 g2 as -> Fan Dec (g1 as) (g2 as)) (:::) (evalDec t sf1) (evalDec t sf2) 

evalDec t (Fst sf) = first (result Fst . argument sfst) (evalDec t sf)

evalDec t (Snd sf) = first (result Snd . argument ssnd) (evalDec t sf)

evalDec t (Loop sfs sff) = case evalDec t sfs of
                             (fs, bs ::: ds) -> let (sff', cs) = eval t sff ds
                                                 in ((\ as -> Loop (fs (as ::: cs)) sff'), bs)

evalDec t (Switch Dec sf f)  = case evalDec t sf of
                                 (g , E Nothing  ::: bs) -> (flip (Switch Dec) f . g , bs)
                                 (_ , E (Just e) ::: _ ) -> evalDec 0 (f e)

evalDec t (DKSwitch Dec sf sfe f) = (g', bs)
                                    where
                                          (g, bs)  =  evalDec t sf

                                          g'       :: SRep as -> SF0 as bs Dec
                                          g' as    =  let sf' = g as
                                                       in case eval t sfe (as ::: bs) of
                                                            (sfe', E Nothing )  ->  DKSwitch Dec sf' sfe' f
                                                            (sfe', E (Just e))  ->  fst (eval 0 (f sf' e) as)
                                    

-----------------------------------------------------------------------------------------

runSF :: Time -> SF as bs d -> SRep as -> (SF as bs d, SRep bs)
runSF t (SF d sf) = first (SF d) . eval t sf

-----------------------------------------------------------------------------------------
