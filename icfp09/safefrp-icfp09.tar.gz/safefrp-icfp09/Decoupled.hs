{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE TypeFamilies #-}

module Decoupled where


-- Decoupledness --------------------------------------------------------

data Dec
data Cau

data DRep :: * -> * where
  Dec :: DRep Dec
  Cau :: DRep Cau


------------------------------------------------------------------------

infixr 2 :>>:
infixr 3 :**:

type family   d1  :>>: d2  :: *
type instance Cau :>>: d2  =  d2
type instance Dec :>>: d2  =  Dec

type family   d1  :**: d2  :: *
type instance Cau :**: d2  =  Cau
type instance Dec :**: d2  =  d2


------------------------------------------------------------------------

infixr 2 .>>.
infixr 3 .**.

(.>>.) :: DRep d1 -> DRep d2 -> DRep (d1 :>>: d2)
Dec .>>. _ = Dec
Cau .>>. d = d


(.**.) :: DRep d1 -> DRep d2 -> DRep (d1 :**: d2)
Dec .**. d = d
Cau .**. _ = Cau

-------------------------------------------------------------------------
