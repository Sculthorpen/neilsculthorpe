{-# LANGUAGE GADTs #-}

module Animator where

import Core
import Reactimator

import Graphics.HGL
import Control.Monad

--------------------------------------------------------

type TickRate  = Integer -- miliseconds
type Duration  = Integer -- miliseconds
type StartTime = Integer -- miliseconds

type WindowSize = (Int, Int)


drawOutput :: Window -> SRep (C Graphic) -> IO ()
drawOutput w (C g) = setGraphic w g

processOutput     :: Window -> SRep (C Graphic) -> IO ()
processOutput w g =  getWindowTick w >> drawOutput w g

checkTime :: StartTime -> Duration -> IO Bool
checkTime t dur = liftM (\t' -> (t' - t >= dur)) getTime


tagTime :: TickRate -> IO (SRep as) -> IO (Core.Time, SRep as) 
tagTime tick = liftM (\as -> (t,as))
               where t = fromIntegral tick / 1000

--------------------------------------------------------------------------------------------------------------

animateIn :: IO (SRep as) -> IO Bool -> SF as (C Graphic) d -> Window -> TickRate -> IO ()
animateIn input finish sf w tick = reactimate (tagTime tick input) (\g -> processOutput w g >> finish) sf

animate :: IO (SRep as) -> IO Bool -> SF as (C Graphic) d -> Title -> WindowSize -> TickRate -> IO ()
animate input finish sf title size tick = runGraphics $ do w <- openWindowEx title Nothing size DoubleBuffered (Just tick)
                                                           animateIn input finish sf w tick
                                                           closeWindow w

animateFor :: IO (SRep as) -> SF as (C Graphic) d -> Title -> WindowSize -> TickRate -> Duration -> IO ()
animateFor input sf title size tick dur = runGraphics $ do w <- openWindowEx title Nothing size DoubleBuffered (Just tick)
                                                           t <- getTime
                                                           animateIn input (checkTime t dur) sf w tick
                                                           closeWindow w


animateInC  :: IO a -> IO Bool -> SF (C a) (C Graphic) d -> Window -> TickRate -> IO ()
animateInC  =  animateIn . liftM C

animateInE  :: IO (Maybe a) -> IO Bool -> SF (E a) (C Graphic) d -> Window -> TickRate -> IO ()
animateInE  =  animateIn . liftM E


animateC    :: IO a -> IO Bool -> SF (C a) (C Graphic) d -> Title -> WindowSize -> TickRate -> IO ()
animateC    =  animate . liftM C

animateE    :: IO (Maybe a) -> IO Bool -> SF (E a) (C Graphic) d -> Title -> WindowSize -> TickRate -> IO ()
animateE    =  animate . liftM E


animateForC :: IO a -> SF (C a) (C Graphic) d -> Title -> WindowSize -> TickRate -> Duration -> IO ()
animateForC =  animateFor . liftM C

animateForE :: IO (Maybe a) -> SF (E a) (C Graphic) d -> Title -> WindowSize -> TickRate -> Duration -> IO ()
animateForE =  animateFor . liftM E


