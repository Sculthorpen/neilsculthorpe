{-# LANGUAGE GADTs               #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeOperators       #-}

-- The naming scheme for the different switch types is to prepend letters describing its behaviour
-- These letters are always prepended in alphabetical order

module Library where

import Primitives
import Nat

--------------------------------------------------------------------------------------------

-- Routing Combinators --

infixr 3 ****

(****)        :: SF as cs d1 -> SF bs ds d2 -> SF (as , bs) (cs , ds) (d1 :**: d2)
sf1 **** sf2  =  toFst sf1 &&&& toSnd sf2

sfFork        :: SF as (as , as) Cau
sfFork        =  identity &&&& identity

sfFst         :: SF (as, bs) as Cau
sfFst         =  toFst identity

sfSnd         :: SF (as, bs) bs Cau
sfSnd         =  toSnd identity

sfSwap        :: SF (as , bs) (bs , as) Cau
sfSwap        =  sfSnd &&&& sfFst


sfSecond      :: SF bs cs d -> SF (as , bs) (as , cs) Cau
sfSecond sf   =  identity **** sf

sfFirst       :: SF as bs d -> SF (as , cs) (bs , cs) Cau
sfFirst sf@(SF Dec _)  =  sf **** identity
sfFirst sf@(SF Cau _)  =  sf **** identity


sfAssoc       :: SF ((as , bs) , cs) (as , (bs , cs)) Cau
sfAssoc       =  toFst sfFst &&&& (toFst sfSnd &&&& sfSnd)
       
sfAssocR      :: SF (as , (bs , cs)) ((as , bs) , cs) Cau
sfAssocR      =  (sfFst &&&& toSnd sfFst) &&&& toSnd sfSnd


snapshotOnEvent :: SF as (E e) d -> SF as (E (SF as (E e) d, e)) Cau
snapshotOnEvent sf  =  snapshot sf >>>> lift2 (,)

snapshotFirstEvent :: SF as (E e, bs) d -> SF as (E (SF as (E e, bs) d, e), bs) Cau
snapshotFirstEvent sf  =  snapshot sf >>>> sfAssocR >>>> sfFirst (lift2 (,))


--------------------------------------------------------------------------------------------

-- Switchless signal functions

-- sfPair        :: SF (s a, t b) ((s :&: t) (a,b)) Cau
-- sfPair        =  lift2 (,)

sample        :: SF (E b , C a) (E a) Cau
sample        =  lift2 (flip const)

mergeL        :: SF (E a , E a) (E a) Cau
mergeL        =  mergeWith const

mergeR        :: SF (E a , E a) (E a) Cau
mergeR        =  mergeWith (flip const)

attach        :: b -> SF (E a) (E (a, b)) Cau
attach b      =  lift (\a -> (a, b))

tag           :: b -> SF (E a) (E b) Cau
tag           =  lift . const

filterEC      :: (e -> c -> Bool) -> SF (E e, C c) (E e) Cau
filterEC f    =  lift2 (,) >>>> filterE (uncurry f) >>>> lift fst


------------------------

-- Edges prefixed with "keen" can generate an event at time zero
-- Those without cannot

edge            :: SF (C Bool) (E ()) Cau
edge            =  iEdge True

keenEdge        :: SF (C Bool) (E ()) Cau
keenEdge        =  iEdge False

edgeJust        :: SF (C (Maybe a)) (E a) Cau
edgeJust        =  iEdgeJust True

keenEdgeJust    :: SF (C (Maybe a)) (E a) Cau
keenEdgeJust    =  iEdgeJust False

iEdgeWhen       :: Bool -> (a -> Bool) -> SF (C a) (E ()) Cau
iEdgeWhen b f   =  lift f >>>> iEdge b

edgeWhen        :: (a -> Bool) -> SF (C a) (E ()) Cau
edgeWhen        =  iEdgeWhen True

keenEdgeWhen    :: (a -> Bool) -> SF (C a) (E ()) Cau
keenEdgeWhen    =  iEdgeWhen False

dedge           :: SF (C Bool) (E ()) Dec
dedge           =  iPre False >>>> edge

dedgeWhen       :: (a -> Bool) -> SF (C a) (E ()) Dec
dedgeWhen f     =  lift f >>>> dedge

-- Given the large number of edge combinators, I don't define
-- all edgeTag combinations

edgeTag         :: a -> SF (C Bool) (E a) Cau
edgeTag a       =  edge >>>> tag a

edgeWhenTag     :: (a -> Bool) -> b -> SF (C a) (E b) Cau
edgeWhenTag f b =  edgeWhen f >>>> tag b

doubleEdge      :: SF (C Bool) (E Bool) Cau
doubleEdge      =  edgeTag True &&&& edgeWhenTag not False >>>> mergeL


---------------------

now            :: SF as (E ()) Dec
now            =  constant True >>>> keenEdge

nowTag         :: a -> SF as (E a) Dec
nowTag a       =  now >>>> tag a

-- PRIVATE?
next           :: SF as (E ()) Dec
next           =  constant True >>>> iPre False >>>> edge


hold           :: a -> SF (E a) (C a) Cau
hold           =  holdWith const

dhold          :: a -> SF (E a) (C a) Dec
dhold a        =  hold a >>>> iPre a

dholdWith      :: (a -> b -> b) -> b -> SF (E a) (C b) Dec
dholdWith f b  =  holdWith f b >>>> iPre b

tagHold        :: b -> b -> SF (E a) (C b) Cau
tagHold t      =  holdWith (\ _ _ -> t)

sampleHold     :: b -> SF (E a , C b) (C b) Cau
sampleHold b   =  sample >>>> hold b


loopPre        :: c -> SF (as , C c) (bs , C c) d -> SF as bs d
loopPre c sf   =  sfLoop sf (iPre c)


integral       :: SF (C Double) (C Double) Cau
integral       =  iIntegral 0

dintegral      :: SF (C Double) (C Double) Dec
dintegral      =  iDintegral 0


--------------------------------------------------------------------------------------------

-- Signal functions defined using switches (see later)

supressInitial           :: SF as (E a) Cau -> SF as (E a) Cau
supressInitial           =  bdswitch never now

notYet                   :: SF (E a) (E a) Cau
notYet                   =  supressInitial identity

initialise               :: a -> SF as (C a) d -> SF as (C a) d
initialise a             =  bdswitch (constant a) now

initially                :: a -> SF (C a) (C a) Cau
initially a              =  initialise a identity


once                     :: SF (E e) (E e) Cau
once                     =  bdswitchWhen identity never

supressHead               :: SF (E a) (E a) Cau
supressHead               =  bdswitch never sfFst identity 

-- PRIVATE?
notYetTakeEvents          :: Nat -> SF (E a) (E a) Cau
notYetTakeEvents 0        =  weaken never
notYetTakeEvents n        =  bdswitchWhen notYet (notYetTakeEvents (n-1))

takeEvents                :: Nat -> SF (E a) (E a) Cau
takeEvents Zero           =  weaken never
takeEvents (Succ n)       =  bdswitchWhen identity (notYetTakeEvents n)

-- PRIVATE?
notYetDropEvents          :: Nat -> SF (E a) (E a) Cau
notYetDropEvents Zero     =  notYet
notYetDropEvents (Succ n) =  bswitchWhen notYet (notYetDropEvents n)

dropEvents                :: Nat -> SF (E a) (E a) Cau
dropEvents Zero           =  identity
dropEvents (Succ n)       =  bswitchWhen identity (notYetDropEvents n) 


-- "after" always enforces a one time sample delay before producing an event, whatever
-- time it is given
-- the down side of this is that "repeatedly 0" becomes an event at every time sample,
-- but that's always going to be possible by doing "repeatedly 0.0000001" or similar

-- this may mean "after" is counterintuitive (after 0 /= now), but on the other
-- hand does make it consistant with "delay"

after                    :: Time -> SF as (E ()) Dec
after t | t <= 0         =  next
        | t >  0         =  time >>>> keenEdgeWhen (>= t)

afterTag                 :: Time -> a -> SF as (E a) Dec
afterTag t a             =  after t >>>> tag a

afterEach                :: [Time] -> SF as (E ()) Dec
afterEach []             =  never
afterEach (t : ts)       =  bdswitchWhen (after t) (afterEach ts)

afterEachTag             :: [(Time , a)] -> SF as (E a) Dec
afterEachTag []          =  never
afterEachTag ((t,a):tas) =  bdswitchWhen (afterTag t a) (afterEachTag tas)

repeatedly               :: Time -> SF as (E ()) Dec
repeatedly t             =  bdnrswitchWhen (after t) (after t)

repeatedlyTag            :: Time -> e -> SF as (E e) Dec
repeatedlyTag t e        =  repeatedly t >>>> tag e

---------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------

--PRIVATE?
coerceIdem :: DRep d -> SF as bs (d :**: d) -> SF as bs d
coerceIdem Dec sf = sf
coerceIdem Cau sf = sf

-- coerceParCau :: DRep d -> SF as bs (d :**: Cau) -> SF as bs Cau
-- coerceParCau Dec sf = sf
-- coerceParCau Cau sf = sf

-- coerceSeq :: DRep d -> SF as bs (d :>>: Cau) -> SF as bs d
-- coerceSeq Dec sf = sf
-- coerceSeq Cau sf = sf

---------------------------------------------------------------------------------------------

-- We avoid kswitch requiring a DRep d2 as an additional argument by
-- weakening the residual signal function
-- this is possible because we know that the overall Decoupledness is Cau

kswitch :: SF as (E e, bs) d1 -> (SF as (E e, bs) d1 -> e -> SF as bs d2) -> SF as bs Cau
kswitch sf f  =  switch Cau (snapshotFirstEvent sf) (weaken . uncurry f)

-- PRIVATE?
kswitchNotYet :: SF as (E e, bs) d1 -> (SF as (E e, bs) d1 -> e -> SF as bs d2) -> SF as bs Cau
kswitchNotYet sf f  =  switch Cau (snapshotFirstEvent sf >>>> sfFirst notYet) (weaken . uncurry f)

-- nrswitch = Neil's Recurring Switch (Neil's alternate rswitch design) {needs a better name & prefix}
-- ideally, nrswitch should be used instead of recursive switch definitions,
-- to ensure the absence of infinite switching within a time sample
-- currently this is enfoced by a "notYet", though this is a rather arbitrary
-- design choice.  Some sort of ePre would also work, as could a merge with
-- the 0th and 1st time samples.  In all cases, its not going to be obvious
-- to the programmer, so I'm not overly happy about it yet.  

nrswitch :: DRep d2 -> SF as (E e, bs) d1 -> (e -> SF as (E e, bs) d2) -> SF as bs (d1 :**: d2)
nrswitch Dec sf f  = switch Dec sf (\ e -> nrswitch Dec (f e >>>> sfFirst notYet) f)
nrswitch Cau sf f  = switch Cau sf (\ e -> nrswitch Cau (f e >>>> sfFirst notYet) f)


knrswitch :: forall as bs e d. SF as (E e, bs) d -> (SF as (E e, bs) d -> e -> SF as (E e, bs) d) -> SF as bs Cau
knrswitch sf f  =  kswitch sf recSwitch
                   where
                     recSwitch :: SF as (E e, bs) d -> e -> SF as bs Cau
                     recSwitch sf' e = kswitchNotYet (f sf' e) recSwitch


-- rswitch is the Yampa rswitch.  Its design doesn't suffer from infinite switching problems,Its simpler than nrswitch
-- but it's not as expressive (we can't define nrswitch (or switch) in terms of it).

rswitch :: SF as bs d1 -> SF (E (SF as bs d2), as) bs Cau
rswitch sf  =  nrswitch Cau (sfSecond sf) sfSecond


-- basic switches don't use the event value

bswitch :: SF as (E e , bs) d1 -> SF as bs d2 -> SF as bs (d1 :**: d2)
bswitch sf1 sf2@(SF d _)    =  switch d sf1 (const sf2)

bnrswitch :: SF as (E e, bs) d1 -> SF as (E e, bs) d2 -> SF as bs (d1 :**: d2)
bnrswitch sf1 sf2@(SF d _)  =  nrswitch d sf1 (const sf2)


-- bswitchWhen consumes an event without emitting it

bswitchWhen :: SF as (E e) d1 -> SF as (E e) d2 -> SF as (E e) (d1 :**: d2)
bswitchWhen sf1@(SF Dec _)  =  bswitch (sf1 &&&& never)
bswitchWhen sf1@(SF Cau _)  =  bswitch (sf1 &&&& never)

-- There is no bnrswitchWhen as it would useless (equivalent to never)

resetswitch :: SF as (E e, bs) d -> SF as bs d
resetswitch sf@(SF d _)     =  coerceIdem d (bnrswitch sf sf)


--------------------------------------------------------------------------------------------------------

-- Decoupled Switches
-- These switches are characterised by their output being from the old signal function at the
-- moment of switching (as opposed to the residual signal function)
-- To allow exploiting the decoupledness this brings, some dswitches have different types to 
-- the corresponding normal switches

dswitch :: DRep d2 -> SF as bs d1 -> SF (as,bs) (E e) d3 -> (e -> SF as bs d2) -> SF as bs (d1 :**: d2)
dswitch d sf sfe f = dkswitch d sf sfe (const f)


dknrswitch :: forall as bs d de e. SF as bs d -> SF (as,bs) (E e) de ->
              (SF as bs d -> SF (as,bs) (E e) de -> e -> (SF as bs d, SF (as,bs) (E e) de)) ->
              SF as bs d

dknrswitch sf@(SF d _) sfe f = coerceIdem d (dkswitch d sf (snapshotOnEvent sfe) recSwitch)
                                 where
                                     recSwitch :: SF as bs d -> (SF (as,bs) (E e) de , e) -> SF as bs d
                                     recSwitch sf' (sfe', e) = uncurry nextswitch (f sf' sfe' e)

                                     nextswitch :: SF as bs d -> SF (as,bs) (E e) de -> SF as bs d
                                     nextswitch sf2 sfe2 =  coerceIdem d (dkswitch d sf2 (snapshotOnEvent sfe2 >>>> notYet) recSwitch)



dnrswitch :: DRep d2 -> SF as bs d1 -> SF (as,bs) (E e) d3 -> (e -> (SF as bs d2, SF (as,bs) (E e) d4)) -> SF as bs (d1 :**: d2)
dnrswitch d sf sfe f = dswitch d sf sfe recSwitch
                         where recSwitch e = let (sf',sfe') = f e
                                              in coerceIdem d (dnrswitch d sf' (sfe' >>>> notYet) f)


drswitch :: DRep d2 -> SF as bs d1 -> SF (E (SF as bs d2), as) bs (d1 :**: d2)
drswitch d sf = dnrswitch d (toSnd sf) (toFst sfFst) (\ sf' -> (toSnd sf', toFst sfFst))


bdswitch :: SF as bs d1 -> SF (as,bs) (E e) d3 -> SF as bs d2 -> SF as bs (d1 :**: d2)
bdswitch sf1 sfe sf2@(SF d _)  =  dswitch d sf1 sfe (const sf2)

-- the following signal functions are particularly useful for defining library SFs

bdnrswitch :: SF as bs d1 -> SF (as,bs) (E e) d3 -> SF as bs d2 -> SF (as,bs) (E e) d4 -> SF as bs (d1 :**: d2)
bdnrswitch sf1 sfe sf'@(SF d _) sfe'  = dnrswitch d sf1 sfe (const (sf', sfe'))

bdswitchWhen :: SF as (E e) d1 -> SF as (E e) d2 -> SF as (E e) (d1 :**: d2)
bdswitchWhen sf1 sf2 = bdswitch sf1 sfSnd sf2

bdnrswitchWhen :: SF as (E e) d1 -> SF as (E e) d2 -> SF as (E e) (d1 :**: d2)
bdnrswitchWhen sf1 sf2 = bdnrswitch sf1 sfSnd sf2 sfSnd


-- dresetswitch is a type of bdnrswitch that switches into the same signal functions
-- it started with.  Note that the event generator resets as well.  If you want an
-- event generator that doesn't reset, you should use a drswitch as that assumes an
-- external event source.

dresetswitch :: SF as bs d1 -> SF (as,bs) (E e) d3 -> SF as bs d1
dresetswitch sf1@(SF d _) sfe = coerceIdem d (bdnrswitch sf1 sfe sf1 sfe)

-----------------------------------------------------------------------------------------------------------------