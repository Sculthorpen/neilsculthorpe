module PongGraphic where

import Data.Maybe
import Control.Concurrent
import Control.Monad

import Graphics.HGL
import Shapes

import Animator
import Primitives
import Pong
import Balls

scale = 10

winHeight = 800
winWidth  = scaleDim rwallPos

paddleHeight = 10
paddleDepth  = 5

paddleLength = scaleDim paddleSize
pypos        = winHeight - paddleHeight - paddleDepth

tickRate = 5 -- miliseconds

duration = 30000 -- 30 seconds

leftRegBorder  = 2 * winWidth `div` 5
rightRegBorder = 3 * winWidth `div` 5


scaleDim :: Distance -> Int
scaleDim x = round (scale * x)

scaleXCo :: XCo -> Int
scaleXCo x = scaleDim x

scaleYCo   :: YCo -> Int
scaleYCo y =  pypos - scaleDim y 

scaleCo :: Co -> (Int,Int)
scaleCo (x,y) = (scaleXCo x, scaleYCo y)


renderBall   :: Point -> Graphic
renderBall (x,y) =  fullCircle (x,y) (scaleDim ballRadius)

renderPaddle :: Int -> Graphic
renderPaddle pxpos =  fullRectangle (pxpos, pypos) (paddleLength, paddleDepth)


renderPong :: PongView -> Graphic
renderPong (PongView b p) = renderPaddle (scaleDim p) `overGraphic` renderBall (scaleCo b)


pongSF :: SF (E PaddleMovement) (C Graphic) Cau
pongSF =  pong >>>> lift renderPong



tryPutMVar_ :: MVar a -> a -> IO ()
tryPutMVar_ mv a =  tryPutMVar mv a >> return ()


pointToMove :: Point -> PaddleMovement
pointToMove (x,_) | x <= leftRegBorder  = Backwards
                  | x >= rightRegBorder = Forewards
                  | otherwise           = Stop

eventToAction :: Event -> Maybe (Either PaddleMovement ())
eventToAction (Button pnt isL True) | isL       = Just (Left (pointToMove pnt))
                                    | otherwise = Just (Right ()) 
eventToAction Closed = Just (Right ())
eventToAction _      = Nothing

processEvent :: MVar PaddleMovement -> MVar () -> Event -> IO ()
processEvent moveMV doneMV e = case eventToAction e of
                                 Nothing         -> return ()
                                 Just (Left pm)  -> tryPutMVar_ moveMV pm
                                 Just (Right ()) -> tryPutMVar_ doneMV ()

detectClicks :: Window -> MVar PaddleMovement -> MVar () -> IO ()
detectClicks w moveMV doneMV = getWindowEvent w >>= processEvent moveMV doneMV >> detectClicks w moveMV doneMV

senseMove :: MVar PaddleMovement -> IO (Maybe PaddleMovement)
senseMove = tryTakeMVar

senseDone :: MVar () -> IO Bool
senseDone = liftM isJust . tryTakeMVar

reactimatePong :: IO ()
reactimatePong =  runGraphics $ do w <- openWindowEx "Pong" Nothing (winWidth, winHeight) DoubleBuffered (Just tickRate)
                                   moveMV <- newEmptyMVar
                                   doneMV <- newEmptyMVar
                                   thId <- forkIO (detectClicks w moveMV doneMV)
                                   animateInE (senseMove moveMV) (senseDone doneMV) pongSF w tickRate  
                                   killThread thId
                                   closeWindow w

main  :: IO ()
main  =  reactimatePong
