{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE UndecidableInstances #-}

module Core where

------------------------------------------------------------------------------

import Decoupled
import Utilities
import Control.Arrow

------------------------------------------------------------------------------

infixr 5 :::

-- Signal Time Domains

data C a
data E a

data SRep :: * -> * where
  C     :: a                -> SRep (C a)
  E     :: Maybe a          -> SRep (E a)
  (:::) :: SRep a -> SRep b -> SRep (a,b)

-- ssplit :: SRep (a, b) -> (SRep a, SRep b)
-- ssplit (a ::: b) = (a,b)

sfst :: SRep (a,b) -> SRep a
sfst (as ::: _) = as

ssnd :: SRep (a,b) -> SRep b
ssnd (_ ::: bs) = bs

sfirst :: (SRep a -> SRep b) -> SRep (a,c) -> SRep (b,c)
sfirst f (a ::: b) = f a ::: b

-- ssecond :: (SRep b -> SRep c) -> SRep (a,b) -> SRep (a,c)
-- ssecond f (a ::: b) = a ::: f b


unC        :: SRep (C a) -> a
unC (C a)  =  a

unE        :: SRep (E a) -> Maybe a
unE (E ma) =  ma

noEvent :: SRep (E a)
noEvent =  E Nothing

event   :: a -> SRep (E a)
event   =  E . Just

mergeE :: (a -> a -> a) -> SRep (E a, E a) -> SRep (E a)
mergeE f (E ma ::: E mb) = E (maybeMergeWith f ma mb)


-------------------------------------------------------------------------------------

smap :: (a -> b) -> SRep (s a) -> SRep (s b)
smap f (C a)  =  C (f a)
smap f (E ma) =  E (fmap f ma)

sextract :: SRep (s a) -> Maybe a
sextract (C a)  = Just a
sextract (E ma) = ma

sassoc :: SRep (as, (bs, cs)) -> SRep ((as , bs) , cs)
sassoc (as ::: (bs ::: cs)) =  (as ::: bs) ::: cs


-- The :&: type operator combines Time Domains when lifting pure functions
-- Note that E is the zero and C is the unit of this operator.

infixl 3 :&:

type family   (s :: * -> *) :&: (t :: * -> *) :: * -> *
type instance C :&: t =  t
type instance E :&: t =  E


sapply :: SRep (s (a -> b) , t a) -> SRep ((s :&: t) b)
sapply (C f        ::: ta) = smap f ta
sapply (E Nothing  ::: _ ) = noEvent
sapply (E (Just f) ::: ta) = E (fmap f (sextract ta))

smap2      :: (a -> b -> c) -> SRep (s a , t b) -> SRep ((s :&: t) c)
smap2 f    = sapply . sfirst (smap f)

-- Beyond smap2, the lack of signal vectors becomes very annoying
-- Unfortunately, I can't seem to use a type class e.g. "class Lift3 sv where..."
-- because I have to give all combinations of C and E as instances
-- (this seems to be due to the not-substituting type variables inside type functions)
-- This would mean 16 cases for smap3, 80 cases for smap4, and presumably some highly unpleasent
-- number for smap5

smap3L     :: (a -> b -> c -> d) -> SRep ((s a, t b) , u c) -> SRep ((s :&: t :&: u) d)
smap3L f   =  sapply . sfirst (smap2 f) 

smap3R     :: (a -> b -> c -> d) -> SRep (s a, (t b , u c)) -> SRep ((s :&: t :&: u) d)
smap3R f   =  smap3L f . sassoc

smap4LL    :: (a -> b -> c -> d -> e) -> SRep (((s a, t b) , u c), v d) -> SRep ((s :&: t :&: u :&: v) e)
smap4LL f  =  sapply . sfirst (smap3L f)

smap4      :: (a -> b -> c -> d -> e) -> SRep ((s a, t b) , (u c, v d)) -> SRep ((s :&: t :&: u :&: v) e)
smap4 f    =  smap4LL f . sassoc

smap4RR    :: (a -> b -> c -> d -> e) -> SRep (s a, (t b , (u c, v d))) -> SRep ((s :&: t :&: u :&: v) e)
smap4RR f  =  smap4 f . sassoc

smap4LR    :: (a -> b -> c -> d -> e) -> SRep ((s a, (t b , u c)), v d) -> SRep ((s :&: t :&: u :&: v) e)
smap4LR f  =  smap4LL f . sfirst sassoc

smap4RL    :: (a -> b -> c -> d -> e) -> SRep (s a, ((t b , u c), v d)) -> SRep ((s :&: t :&: u :&: v) e)
smap4RL f  =  smap4LR f . sassoc


-------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------

-- Time --

type Time = Double

type Dt = Time


---------------------------------------------------------------------------------------------------

-- Signal Function Representation --


data SF0 :: * -> * -> * -> * where

  Constant :: SRep bs                                                                            -> SF0 as bs Dec

  Identity ::                                                                                       SF0 as as Cau

  Prim     :: (Dt -> state -> SRep as -> (state, SRep bs)) -> state                              -> SF0 as bs Cau

  DPrim    :: (Dt -> state -> ((SRep as -> state), SRep bs)) -> state                            -> SF0 as bs Dec

  Weaken   :: SF0 as bs d                                                                        -> SF0 as bs Cau

  Seq      :: DRep d1 -> SF0 as bs d1 -> SF0 bs cs d2                                            -> SF0 as cs (d1 :>>: d2)

  Fan      :: DRep d1 -> SF0 as bs d1 -> SF0 as cs d2                                            -> SF0 as (bs,cs) (d1 :**: d2)

  Fst      :: SF0 as cs d                                                                        -> SF0 (as,bs) cs d

  Snd      :: SF0 bs cs d                                                                        -> SF0 (as,bs) cs d

  Switch   :: DRep d1 -> SF0 as (E e , bs) d1 -> (e -> SF0 as bs d2)                             -> SF0 as bs (d1 :**: d2)

  DKSwitch :: DRep d1 -> SF0 as bs d1 -> SF0 (as,bs) (E e) d3 -> (SF0 as bs d1 -> e -> SF0 as bs d2) -> SF0 as bs (d1 :**: d2)
 
  Loop     :: SF0 (as,cs) (bs,ds) d -> SF0 ds cs Dec                                             -> SF0 as bs d

  Snapshot :: DRep d -> SF0 as bs d                                                              -> SF0 as (C (SF as bs d), bs) Cau


data SF as bs d = SF (DRep d) (SF0 as bs d)

unSF :: SF as bs d -> SF0 as bs d
unSF (SF _ sf) = sf

mapSF :: (SF0 as bs d -> SF0 cs ds d) -> SF as bs d -> SF cs ds d 
mapSF f (SF d sf) = SF d (f sf)


----------------------------------------------------------------------------------------------------

constantly     :: SRep bs -> SF as bs Dec
constantly     =  SF Dec . Constant

prim           :: (Dt -> state -> SRep as -> (state, SRep bs)) -> state -> SF as bs Cau
prim f         =  SF Cau . Prim f

dprim          :: (Dt -> state -> ((SRep as -> state), SRep bs)) -> state -> SF as bs Dec
dprim f        =  SF Dec . DPrim f

mkStateless    :: (SRep as -> SRep bs) -> SF as bs Cau
mkStateless f  =  prim (\ _ _ as -> (() , f as)) ()

mkSource       :: (Dt -> state -> (state , SRep bs)) -> state -> SF as bs Dec
mkSource f     =  dprim (\ t s -> first const (f t s)) 

----------------------------------------------------------------------------------------------------


