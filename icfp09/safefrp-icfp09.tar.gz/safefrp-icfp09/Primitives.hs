{-# LANGUAGE GADTs #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeOperators #-}

module Primitives (

module Primitives,
module Decoupled,
SF(..),
C,
E,
Time

) where

import Data.Maybe
import Control.Monad
import Control.Arrow
import Queue
import Utilities

import Decoupled
import Core

--------------------------------------------------------------------------------------------

infixr 2 >>>>
infixr 3 &&&&

identity                       :: SF as as Cau
identity                       =  SF Cau Identity

weaken                         :: SF as bs d -> SF as bs Cau
weaken                         =  SF Cau . Weaken . unSF

(>>>>)                         :: SF as bs d1 -> SF bs cs d2 -> SF as cs (d1 :>>: d2)
SF d1 sf1 >>>> SF d2 sf2       =  SF (d1 .>>. d2) (Seq d1 sf1 sf2)

(&&&&)                         :: SF as bs d1 -> SF as cs d2 -> SF as (bs,cs) (d1 :**: d2)
SF d1 sf1 &&&& SF d2 sf2       =  SF (d1 .**. d2) (Fan d1 sf1 sf2)

toFst                          :: SF as cs d -> SF (as,bs) cs d 
toFst                          =  mapSF Fst

toSnd                          :: SF bs cs d -> SF (as,bs) cs d
toSnd                          =  mapSF Snd

switch                         :: DRep d2 -> SF as (E e , bs) d1 -> (e -> SF as bs d2) -> SF as bs (d1 :**: d2)
switch d2 (SF d1 sf) f         =  SF (d1 .**. d2) (Switch d1 sf (unSF . f))

dkswitch                       :: DRep d2 -> SF as bs d1 -> SF (as,bs) (E e) d3 -> (SF as bs d1 -> e -> SF as bs d2) -> SF as bs (d1 :**: d2)
dkswitch d2 (SF d1 sf) (SF _ sfe) f  =  SF (d1 .**. d2) (DKSwitch d1 sf sfe f0)
                                        where f0 sf0 = unSF . f (SF d1 sf0)

sfLoop                         :: SF (as,cs) (bs,ds) d -> SF ds cs Dec -> SF as bs d
sfLoop (SF d sfs) (SF Dec sff) =  SF d (Loop sfs sff)

snapshot                       :: SF as bs d -> SF as (C (SF as bs d), bs) Cau
snapshot (SF d sf)             =  SF Cau (Snapshot d sf)

--------------------------------------------------------------------------------------------

constant      :: a -> SF as (C a) Dec
constant      =  constantly . C

never         :: SF as (E a) Dec
never         =  constantly noEvent


--------------------------------------------------------------------------------------------

lift          :: (a -> b) -> SF (s a) (s b) Cau
lift          =  mkStateless . smap

lift2         :: (a -> b -> c) -> SF (s a , t b) ((s :&: t) c) Cau
lift2         =  mkStateless . smap2


-- the lack of signal vectors begins to hurt here
-- mind you, if the main purpose of this is for translation from syntatic sugar, then that's not a problem
-- as we can just define the rightmost nesting upto lift8 or whatever

-- an alternative would be to have two lift families, liftC and liftE, characterised by whether they produce
-- an event or continuous.  liftC would have to be applied to all Continuous signals, but liftE wouldn't be so limited.
-- Hmmm.  But then we'd have to be careful to ensure that liftE contained at least one E, else it'd be a constant event
-- occurrence.  Which is very bad.

-- Update: I don't think the latter option works without enumerating all the type classes instance combinations
-- of C and E

lift3L       :: (a -> b -> c -> d) -> SF ((s a , t b) , u c) ((s :&: t :&: u) d) Cau
lift3L       =  mkStateless . smap3L

lift3R       :: (a -> b -> c -> d) -> SF (s a , (t b , u c)) ((s :&: t :&: u) d) Cau
lift3R       =  mkStateless . smap3R

lift4        :: (a -> b -> c -> d -> e) -> SF ((s a, t b) , (u c, v d)) ((s :&: t :&: u :&: v) e) Cau
lift4        =  mkStateless . smap4

lift4LL      :: (a -> b -> c -> d -> e) -> SF (((s a, t b) , u c), v d) ((s :&: t :&: u :&: v) e) Cau
lift4LL      =  mkStateless . smap4LL

lift4RR      :: (a -> b -> c -> d -> e) -> SF (s a, (t b , (u c, v d))) ((s :&: t :&: u :&: v) e) Cau
lift4RR      =  mkStateless . smap4RR

lift4LR      :: (a -> b -> c -> d -> e) -> SF ((s a, (t b , u c)), v d) ((s :&: t :&: u :&: v) e) Cau
lift4LR      =  mkStateless . smap4LR

lift4RL      :: (a -> b -> c -> d -> e) -> SF (s a, ((t b , u c), v d)) ((s :&: t :&: u :&: v) e) Cau
lift4RL      =  mkStateless . smap4RL



mergeWith    :: (a -> a -> a) -> SF (E a , E a) (E a) Cau
mergeWith    =  mkStateless . mergeE

-- sampleWith    :: forall e c b. (e -> c -> b) -> SF (E e , C c) (E b) Cau
-- sampleWith f  =  mkStateless sampleAux
--                  where
--                    sampleAux :: SRep (E e, C c) -> SRep (E b)
--                    sampleAux (emb ::: C c) = emap (flip f c) emb

filterE      :: forall a. (a -> Bool) -> SF (E a) (E a) Cau
filterE p    =  mkStateless filterEAux
                where
                  filterEAux :: SRep (E a) -> SRep (E a)
                  filterEAux (E (Just a)) | p a = event a
                  filterEAux _                  = noEvent


-- The Boolean paramater to edge says what the previous input is
-- assumed to have been.  This determines whether an event can
-- occur at time zero.

iEdge         :: Bool -> SF (C Bool) (E ()) Cau
iEdge         =  prim (const edgeAux)
                 where
                   edgeAux :: Bool -> SRep (C Bool) -> (Bool , SRep (E ()))
                   edgeAux s (C b) = (b , if b && not s then event () else noEvent)


-- The Boolean paramater to iEdgeJust says whether the previous input
-- is considered to have been Just (True) or Nothing (False)

iEdgeJust     :: forall a. Bool -> SF (C (Maybe a)) (E a) Cau
iEdgeJust     =  prim (const edgeJustAux)
  where
    edgeJustAux :: Bool -> SRep (C (Maybe a)) -> (Bool , SRep (E a))
    edgeJustAux _     (C Nothing)  = (False, noEvent)
    edgeJustAux True  _            = (True,  noEvent)
    edgeJustAux False (C (Just a)) = (True,  event a)


holdWith      :: forall a b. (a -> b -> b) -> b -> SF (E a) (C b) Cau
holdWith f    =  prim (const holdAux)
                 where
                   holdAux :: b -> SRep (E a) -> (b , SRep (C b))
                   holdAux s (E Nothing)  = (s, C s)
                   holdAux s (E (Just a)) = (b, C b)
                                          where b = f a s 

iPre          :: a -> SF (C a) (C a) Dec
iPre          =  dprim (\ _ s -> (id,s)) . C

time          :: SF as (C Time) Dec
time          =  mkSource (\ dt s -> let t = dt + s in (t, C t)) 0


iIntegral     :: Double -> SF (C Double) (C Double) Cau
iIntegral     =  prim (\ t s ca -> let x = t * unC ca + s in (x, C x))

-- iDintegral stores the total and the previous input value in its state

iDintegral    :: Double -> SF (C Double) (C Double) Dec
iDintegral i  =  dprim (\ t (oldtot,olda) -> let newtot = t * olda + oldtot in ((,) newtot . unC, C newtot))
                      (i,0)

---------------------------------------------------------------------------------------------

type ReleaseTime = Time
type CurrentTime = Time

type DelayQueue a = Queue (ReleaseTime, a)


deQueueIfTime :: CurrentTime -> DelayQueue a -> Maybe (DelayQueue a, a)
deQueueIfTime tnow = fmap (second snd) . deQueueIf ((tnow >) . fst)

deQueueUntilTime :: CurrentTime -> DelayQueue a -> Maybe (DelayQueue a, a)
deQueueUntilTime tnow q = case deQueueWhileR ((tnow >) . fst) q of
                            (_ , [] )      -> Nothing
                            (q', (_,a):_)  -> Just (q', a)

-----------------------------------------------------

type TimeDelay   = Time

type DelayCState a = (CurrentTime , a , DelayQueue a)

delayC :: forall a. TimeDelay -> a -> SF (C a) (C a) Dec
delayC tdelay a = dprim delayAux (0 , a , emptyQ)
  where
    delayAux :: Dt -> DelayCState a -> ((SRep (C a) -> DelayCState a) , SRep (C a))
    delayAux dt (told, aold, q) = (delayAuxd , C aout) 
      where tnow       :: CurrentTime
            tnow       =  dt + told

            (q', aout) =  maybe (q,aold) id (deQueueUntilTime tnow q)


            delayAuxd         :: SRep (C a) -> DelayCState a
            delayAuxd (C ain) =  (tnow, aout, enQueue ((tnow + tdelay) , ain) q')

-----------------------------------------------------

type DelayEState a = (CurrentTime , DelayQueue a)

delayE :: forall a. TimeDelay -> SF (E a) (E a) Dec
delayE tdelay = dprim delayEAux (0 , emptyQ)
  where
    delayEAux :: Dt -> DelayEState a -> ((SRep (E a) -> DelayEState a) , SRep (E a))
    delayEAux dt (told , q) = (delayAuxd , E eout)
      where
        tnow          :: CurrentTime
        tnow          =  dt + told

        (q', eout)    =  maybe (q,Nothing) (second Just) (deQueueIfTime tnow q)

        delayAuxd     :: SRep (E a) -> DelayEState a
        delayAuxd (E Nothing)    = (tnow, q')
        delayAuxd (E (Just ein)) = (tnow, enQueue ((tnow + tdelay) , ein) q')


---------------------------------------------------------------------------------------------
