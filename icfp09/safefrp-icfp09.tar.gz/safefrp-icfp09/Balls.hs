module Balls where

import Primitives
import Library

import ICFP09

-------------------------------------------------------------------

type Velocity     = Double
type Acceleration = Double
type Distance     = Double
type Height       = Distance
type BallRadius   = Distance

gravity :: Acceleration
gravity =  9.81

accelerator :: Acceleration -> Velocity -> Distance -> SF as (C Distance, C Velocity) Dec
accelerator a v s = constant a >>>> iIntegral v >>>> iIntegral s &&&& identity

falling :: Velocity -> Height -> SF as (C Height, C Velocity) Dec
falling =  accelerator (-gravity)

-- of course, detect bounce could not return the distance, and we could use
-- the collision distance.  That'd make the bouncing slightly unstable though.

detectBounce :: (Distance -> Velocity -> Bool) -> SF (C Distance, C Velocity) (E (Distance, Velocity)) Cau
detectBounce p = lift2 (,) >>>> edgeWhen (uncurry p) &&&& identity >>>> sample

bouncer :: (Distance -> Velocity -> Bool) -> Acceleration -> Velocity -> Distance -> SF as (C Distance, C Velocity) Dec
bouncer p a v s = nrswitch Dec (bouncerAux v s) (\(s', v') -> bouncerAux (-v') s')
                  where
                        bouncerAux :: Velocity -> Distance -> SF as (E (Distance, Velocity) , (C Distance, C Velocity)) Dec
                        bouncerAux v' s' = accelerator a v' s' >>>> detectBounce p &&&& identity


type Floor   = Height
type Ceiling = Height

floorBounce :: Floor -> Distance -> Velocity -> Bool
floorBounce f d v = d <= f && v < 0

ceilingBounce :: Ceiling -> Distance -> Velocity -> Bool
ceilingBounce c d v = d >= c && v > 0

doubleBounce :: Floor -> Ceiling -> Distance -> Velocity -> Bool
doubleBounce f c d v = floorBounce f d v || ceilingBounce c d v


floorBouncer   :: Floor -> Acceleration -> Velocity -> Distance -> SF as (C Distance, C Velocity) Dec
floorBouncer f =  bouncer (floorBounce f)

ceilingBouncer   :: Ceiling -> Acceleration -> Velocity -> Distance -> SF as (C Distance, C Velocity) Dec
ceilingBouncer c =  bouncer (ceilingBounce c)

doubleBouncer :: Floor -> Ceiling -> Acceleration -> Velocity -> Distance -> SF as (C Distance, C Velocity) Dec
doubleBouncer f c = bouncer (doubleBounce f c)


bouncingBall      :: BallRadius -> Height -> SF as (C Height) Dec
bouncingBall r h  =  floorBouncer r (-gravity) 0 h >>>> sfFst


clampedBall      :: BallRadius -> Height -> SF as (C Height) Dec
clampedBall r h  =  bouncingBall r h >>>> clamp


------------------------------------------------------------------
