{-# LANGUAGE EmptyDataDecls #-}

module ICFP09 where

import Primitives
import Library

--------------------------------------------------------------------

-- examples from "Safe Functional Reactive Programming through Dependent Types"
-- ICFP 2009

-- clamp sets the output to zero once it dips below zero

clamp :: Real a => SF (C a) (C a) Cau
clamp =  bswitch (edgeWhen (< 0) &&&& identity) (constant 0)


-- dynIntgr switches between integrators

type Input  = Double
type Output = Double

type Intgr  = SF (C Input) (C Output) Cau
type DIntgr = SF (C Input) (C Output) Dec

data DecisionRules

type NewIntgr = (DIntgr, DecisionRules)

intgrDecider :: SF ((E NewIntgr , C Input) , C Output)
                   (C Output , (E DIntgr, C Input))
                   Cau

intgrDecider = undefined


dynIntgr :: SF (E NewIntgr, C Input) (C Output) Cau
dynIntgr =  sfLoop intgrDecider (drswitch Dec dintegral)


----------------------------------------------------------------------
