module BounceGraphic where

import Graphics.HGL
import Shapes

import Animator
import Primitives
import Balls

winWidth  = 400
winHeight = 800

floorPos = winHeight

tickRate = 5 -- miliseconds

scale = 10

duration = 30000 -- 30 seconds


heightToBall   :: Height -> Graphic
heightToBall h =  fullCircle (round (scale * xco), floorPos - round (scale * h)) (round (scale * ballRadius))

-- these numbers are in model size
xco = 15
initialHeight = 70
ballRadius = 1.5

bounceSF :: SF as (C Graphic) Dec
bounceSF =  bouncingBall ballRadius initialHeight >>>> lift heightToBall

main :: IO ()
main =  animateForC (return ()) bounceSF "Bouncing Ball" (winWidth, winHeight) tickRate duration
