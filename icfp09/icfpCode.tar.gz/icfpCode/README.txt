This archive contains accompanying code for the paper "Safe Functional Reactive Programming through Dependent Types". (Proceedings of ICFP '09)

There are three versions: "icfp09", "icfp09Full" and "icfpSet1".  "icfp09" corresponds to the semantics given in the paper, but does not allow any uninitialised signals (unlike "icfp09Full" which does).  However the "icfp09" version is far simpler and much more readable.  Including uninitialised signals greatly complicates the implementation, requiring lots of coercians and accompanying proofs.

"icfp09Set1" is the same as "icfp09", but rewritten to avoid requiring the "type-in-type" flag.  This makes the code uglier and requires some duplication because Agda does not support universe polymorphism.  Its purpose is to prove we are not exploiting the unsoundess of the "type-in-type" flag, and that the rest of our code could be similarly translated.  

You will need a recent version (I suggest 2.2.2 or higher) of Agda.  See http://wiki.portal.chalmers.se/agda/

I use my own library (NeilLib) rather than the Agda Standard Library, so you will not need to download the Agda Standard Library.  You will need to put NeilLib in your search path (in the agda2-mode.el file when setting up emacs mode), or copy all the files into the same directory as the FRP files.  Be aware this library is designed purely for my own use -- I make no claims as to its quality.

Remember, this is a proof of concept implementation.  Its purpose is to demonstrate the safety guarantees, not to run real programs.
