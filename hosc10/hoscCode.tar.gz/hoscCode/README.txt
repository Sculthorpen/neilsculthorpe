This archive contains accompanying code for the paper "Keeping Calm in the Face of Change: Towards Optimisation of FRP by Reasoning about Change". (Submitted to HOSC)

You will need a recent version (it's been tested under 2.2.6) of Agda.  See http://wiki.portal.chalmers.se/agda/

I use my own library (NeilLib) rather than the Agda Standard Library, so you will not need to download the Agda Standard Library.  You will need to put NeilLib in your search path (in the agda2-mode.el file when setting up emacs mode), or copy all the files into the same directory as the FRP files.  Be aware this library is designed purely for my own use -- I make no claims as to its quality.
