{-# LANGUAGE Arrows #-}

module Alien where

-- Note: this code involves lots of duplication of code for the Alien and the Paddle.
--       a better design would be to abstract over solid rectangular objects.

import FRP.Yampa
import FRP.Yampa.Geometry

import Ball (Position,iIntegral)
import Balls

import Pong

-------------------------------------------------------------------------

data Alien = Alien
               { alienCentrePoint :: Position2
               , alienHeight      :: Height
               , alienWidth       :: Width
               , alienSpeed       :: Speed
               }

bigAlStartPos :: Position2
bigAlStartPos = vector2 0.5 0.7

littleAlStartPos :: Position2
littleAlStartPos = vector2 0.8 0.2

bigAlien :: Alien
bigAlien = Alien
                 { alienCentrePoint = bigAlStartPos
                 , alienHeight      = 0.07
                 , alienWidth       = 0.1
                 , alienSpeed       = 0.3
                 }

littleAlien :: Alien
littleAlien = Alien
                 { alienCentrePoint = littleAlStartPos
                 , alienHeight      = 0.035
                 , alienWidth       = 0.05
                 , alienSpeed       = 0.1
                 }

-------------------------------------------------------------------------

alienLeftEdge :: Alien -> Position
alienLeftEdge al = vector2X (alienCentrePoint al) - alienWidth al / 2

alienRightEdge :: Alien -> Position
alienRightEdge al = vector2X (alienCentrePoint al) + alienWidth al / 2

alienBotEdge :: Alien -> Position
alienBotEdge al = vector2Y (alienCentrePoint al) - alienHeight al / 2

alienTopEdge :: Alien -> Position
alienTopEdge al = vector2Y (alienCentrePoint al) + alienHeight al / 2

-------------------------------------------------------------------------

-- Ball/Alien interaction

-- is the ball vertically aligned with the paddle
alienVerticalHit :: Alien -> Ball2 -> Bool
alienVerticalHit p b =    ballPosX b + ballRad b > alienLeftEdge p
                       && ballPosX b - ballRad b < alienRightEdge p

-- is the ball horizontally aligned with the paddle
alienHorizontalHit :: Alien -> Ball2 -> Bool
alienHorizontalHit p b =     ballPosY b - ballRad b < alienTopEdge p
                          && ballPosY b + ballRad b > alienBotEdge p

alienTopBounce :: BounceDetector (Ball2, Alien)
alienTopBounce = proc (b,p) -> do
                   e <- edgeTag ybounce -< ballPosY b - ballRad b < alienTopEdge p
                   returnA              -< gate e (alienVerticalHit p b)

alienBotBounce :: BounceDetector (Ball2, Alien)
alienBotBounce = proc (b,p) -> do
                   e <- edgeTag ybounce -< ballPosY b + ballRad b > alienBotEdge p
                   returnA              -< gate e (alienVerticalHit p b)

alienLeftBounce :: BounceDetector (Ball2, Alien)
alienLeftBounce = proc (b,p) -> do
                    e <- edge -< ballPosX b + ballRad b > alienLeftEdge p
                    returnA   -< tagWith (modVel p) (gate e (alienHorizontalHit p b))
  where
        modVel p v = if vector2X v > 0 then xbounce v else modify2X (\ x -> x - alienSpeed p) v

alienRightBounce :: BounceDetector (Ball2, Alien)
alienRightBounce = proc (b,p) -> do
                     e <- edge -< ballPosX b - ballRad b < alienRightEdge p
                     returnA   -< tagWith (modVel p) (gate e (alienHorizontalHit p b))
  where
        modVel p v = if vector2X v < 0 then xbounce v else modify2X (\ x -> x + alienSpeed p) v

alienDetector :: BounceDetector (Ball2, Alien)
alienDetector = mergeDetectors [alienTopBounce, alienBotBounce, alienLeftBounce, alienRightBounce]

-------------------------------------------------------------------------

alienBalls :: [Ball2] -> SF (Event Ball2, (Paddle,(Alien,Alien))) [Ball2]
alienBalls = loseableNewBalls $ mergeDetectors
                    [ fst              ^>> wallsAndCeilingDetector
                    , second fst       ^>> paddleDetector
                    , second (fst.snd) ^>> alienDetector -- bigAl
                    , second (snd.snd) ^>> alienDetector -- littleAl
                    ]

-------------------------------------------------------------------------

type AlienBallSF = SF (Paddle,Alien) (Ball2, Event ())

-------------------------------------------------------------------------

alienSF :: [Ball2] -> Paddle -> PaddleAI -> SF (Event Position2) ([Ball2],Paddle,[Alien])
alienSF bs0 pad0 ai = proc ep -> do
                            rec bigAl    <- bigAlienSF                             -< ep
                                littleAl <- littleAlienSF                          -< alienCentrePoint bigAl
                                eb       <- alienGun                               -< bigAl
                                bs       <- alienBalls bs0                         -< (eb,(pad,(bigAl,littleAl)))
                                pad      <- paddle pad0 <<< ai <<< iPre (bs0,pad0) -< (bs,pad)
                            returnA                                                -< (bs,pad,[bigAl,littleAl])

-------------------------------------------------------------------------

alienExample :: SF (Event Position2) ([Ball2],Paddle,[Alien])
alienExample = alienSF defaultPongBalls defaultPaddle steadyPlannerAI

-------------------------------------------------------------------------

-- Alien behaviour

type Distance = Double

bigAlCloseEnough :: Distance
bigAlCloseEnough = 0.01

littleAlCloseEnough :: Distance
littleAlCloseEnough = 0.15

alienVel :: Speed -> Position2 -> Position2 -> Velocity2
alienVel sp pos target = let v = (target ^-^ pos)
                             theta = vector2Theta v
                             x = sp * cos theta
                             y = sp * sin theta
                          in vector2 x y

distanceBetween2 :: Position2 -> Position2 -> Distance
distanceBetween2 p1 p2 = let (x,y) = vector2XY (p1 ^-^ p2)
                          in sqrt (x^2 + y^2)

-------------------------------------------------------------------------

alienMoveToward :: Distance -> Alien -> SF Position2 Alien
alienMoveToward d al0 = let pos0 = alienCentrePoint al0
                        in proc target -> do
                             rec pos <- iIntegral pos0 <<< iPre pos0 -< if distanceBetween2 pos target < d
                                                                         then vector2 0 0
                                                                         else alienVel (alienSpeed al) pos target
                                 let al = al0 {alienCentrePoint = pos}
                             returnA -< al

bigAlienSF :: SF (Event Position2) Alien
bigAlienSF = hold bigAlStartPos >>> alienMoveToward bigAlCloseEnough bigAlien

littleAlienSF :: SF Position2 Alien
littleAlienSF = alienMoveToward littleAlCloseEnough littleAlien

-------------------------------------------------------------------------

alienGun :: SF Alien (Event Ball2)
alienGun = proc al -> do
             e <- repeatedly 1 () -< ()
             returnA              -< tagWith (fireGun al) e
  where
    fireGun :: Alien -> Ball2
    fireGun al = Ball2
                     { ballRad = alienHeight al / 8
                     , ballPos = modify2Y (\ y -> y - alienHeight al / 4) (alienCentrePoint al)
                     , ballVel = vector2 0.1 (-0.3)
                     , ballCol = "red"
                     }

-------------------------------------------------------------------------
