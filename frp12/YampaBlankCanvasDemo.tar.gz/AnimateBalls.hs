module AnimateBalls where

import FRP.Yampa
import FRP.Yampa.Geometry
import FRP.Yampa.Event

import Balls
import Animator

import Graphics.Blank hiding (Event)

-- set browser to: http://localhost:3000/

main :: IO ()
main = blankCanvas 3000 $ runSFcanvas clickNewBall newBallsExample renderBalls

clickNewBall :: Canvas (Event Position2)
clickNewBall =
  do mne <- tryReadEvents [MouseDown]
     case mne of
       Just (NamedEvent MouseDown e) -> case jsMouse e of
                                          Nothing    -> return NoEvent
                                          Just (x,y) -> do bx <- toscaleX x
                                                           by <- toscaleY y
                                                           return (Event (vector2 bx by))
       _                             -> return NoEvent

renderBall :: Ball2 -> Canvas ()
renderBall b = do x <- scaleX (ballPosX b)
                  y <- scaleY (ballPosY b)
                  r <- scaleLength (ballRad b)
                  circle x y r (ballCol b)

renderBalls :: [Ball2] -> Canvas ()
renderBalls = mapM_ renderBall
