module AnimateAlien where

import FRP.Yampa
import FRP.Yampa.Geometry
import FRP.Yampa.Event

import Balls
import Pong
import Alien
import Animator
import AnimateBalls hiding (main)
import AnimatePong hiding (main)

import Graphics.Blank hiding (Event)

-- set browser to: http://localhost:3000/

main :: IO ()
main = blankCanvas 3000 $ runSFcanvas clickNewBall alienExample renderBPA

renderBPA :: ([Ball2],Paddle,[Alien]) -> Canvas ()
renderBPA (bs,p,als) = renderBalls bs >> renderPaddle p >> mapM_ renderAlien als

renderAlien :: Alien -> Canvas ()
renderAlien al = do x <- scaleX (alienLeftEdge al)
                    y <- scaleY (alienTopEdge al)
                    w <- scaleWidth (alienWidth al)
                    h <- scaleHeight (alienHeight al)
                    rectangle x y w h "black"
                    rectangle (x + w*0.3) (y + h*3/5) (w*0.4) (h*2/5) "red"
                    let eyeY  = y + (h / 3)
                        eyeX1 = x + (w / 4)
                        eyeX2 = x + (w * 3 / 4)
                        eyeInnerRad = w / 15
                        eyeOuterRad = w / 10
                    renderEye eyeX1 eyeY eyeOuterRad eyeInnerRad
                    renderEye eyeX2 eyeY eyeOuterRad eyeInnerRad

renderEye :: XCo -> YCo -> Radius -> Radius -> Canvas ()
renderEye x y outer inner = do circle x y outer "yellow"
                               circle x y inner "red"
