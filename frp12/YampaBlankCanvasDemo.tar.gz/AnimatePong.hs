module AnimatePong where

import FRP.Yampa
import FRP.Yampa.Geometry
import FRP.Yampa.Event

import Pong
import Animator
import AnimateBalls hiding (main)

import Graphics.Blank hiding (Event)

-- set browser to: http://localhost:3000/

import Balls

main :: IO ()
main = blankCanvas 3000 $ runSFcanvas clickNewBall pongExample renderBallsAndPaddle

renderBallsAndPaddle :: ([Ball2],Paddle) -> Canvas ()
renderBallsAndPaddle (bs,p) = renderBalls bs >> renderPaddle p

renderPaddle :: Paddle -> Canvas ()
renderPaddle p = do x <- scaleX (padLeftEdge p)
                    y <- scaleY (padTopEdge p)
                    w  <- scaleWidth (padWidth p)
                    h  <- scaleHeight (padHeight p)
                    rectangle x y w h (padCol p)