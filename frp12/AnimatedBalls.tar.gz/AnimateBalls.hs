module AnimateBalls where

import FRP.Yampa
import FRP.Yampa.Geometry
import FRP.Yampa.Event

import Balls
import Animator

import Graphics.Blank hiding (Event)

main :: IO ()
main = blankCanvas 3000 $ \ canvas -> do q <- events canvas MouseDown
                                         runSFcanvas (clickNewBall canvas q) (newBalls balls2) renderBalls canvas

clickNewBall :: Context -> EventQueue -> IO (Event Position2)  
clickNewBall canvas q = do me <- tryReadEventQueue q
                           case me >>= jsMouse of
                             Nothing    -> return NoEvent   
                             Just (x,y) -> send canvas $ do bx <- toscaleX x
                                                            by <- toscaleY y
                                                            return (Event (vector2 bx by))

renderBall :: Colour -> Ball2 -> Canvas ()
renderBall col (r,p,_) = do x <- scaleX (vector2X p)
                            y <- scaleY (vector2Y p)
                            r' <- scaleLength r
                            circle x y r' col

renderBalls :: [Ball2] -> Canvas ()
renderBalls bs = mapM_ (uncurry renderBall) (zip (cycle somecolours) bs)
