module AnimateBall where

import Balls
import Animator

import Graphics.Blank

main :: IO ()
main = blankCanvas 3000 (runSFcanvas (return ()) (bouncingBall ball1) renderBall)
  
defaultBallX :: Canvas XCo
defaultBallX = do (x,_) <- size
                  return (x/2)

renderBall :: Ball -> Canvas ()
renderBall (r,h,_) = do x <- defaultBallX
                        y <- scaleY h
                        r' <- scaleLength r
                        circle x y r' "black"
