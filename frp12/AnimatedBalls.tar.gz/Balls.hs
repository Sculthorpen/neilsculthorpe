{-# LANGUAGE Arrows #-}

module Balls where

import FRP.Yampa
import FRP.Yampa.Geometry

-------------------------------------------------------------------------

-- Types

type Acceleration = Double
type Velocity     = Double
type Height       = Double
type Radius       = Double
type Ball         = (Radius,Height,Velocity)

-------------------------------------------------------------------------

-- Constants

g :: Acceleration
g = -0.5

elasticity :: Double
elasticity = -0.98

-------------------------------------------------------------------------

-- Bouncing Ball

fallingBall :: Ball -> SF a Ball
fallingBall (r,h0,v0) = proc _ -> do
                          v <- iIntegral v0 -< g
                          h <- iIntegral h0 -< v
                          identity          -< (r,h,v)

detectBounce :: SF Ball (Event Ball)
detectBounce = proc (r,h,v) -> do
                 e <- edge  -<  h <= r
                 identity   -<  tag e (r, h, v * elasticity)

bouncingBall :: Ball -> SF a Ball
bouncingBall b = switchWhen (fallingBall b) detectBounce bouncingBall

ball1 :: Ball
ball1 = (0.04,0.8,0)

-------------------------------------------------------------------------

-- 2D Bouncing Balls

type Acceleration2 = Vector2 Acceleration 
type Velocity2     = Vector2 Velocity
type Position2     = Vector2 Double
type Ball2         = (Radius, Position2, Velocity2)

g2 :: Acceleration2
g2 = vector2 0 (-1)

xbounceVel :: Velocity2 -> Velocity2
xbounceVel = modify2X (* elasticity)

ybounceVel :: Velocity2 -> Velocity2
ybounceVel = modify2Y (* elasticity)


fallingBall2 :: Ball2 -> SF a Ball2
fallingBall2 (r,p0,v0) = proc _ -> do
                           v <- iIntegral v0 -< g2
                           p <- iIntegral p0 -< v
                           identity          -< (r,p,v)

floorBounce :: SF Ball2 (Event (Velocity2 -> Velocity2))
floorBounce = arr (\ (r,pos,_) -> vector2Y pos <= r) >>> edgeTag ybounceVel

ceilingBounce :: SF Ball2 (Event (Velocity2 -> Velocity2))
ceilingBounce = arr (\ (r,pos,_) -> vector2Y pos + r >= 1) >>> edgeTag ybounceVel

wallBounceL :: SF Ball2 (Event (Velocity2 -> Velocity2))
wallBounceL = arr (\ (r,pos,_) -> vector2X pos <= r) >>> edgeTag xbounceVel

wallBounceR :: SF Ball2 (Event (Velocity2 -> Velocity2))
wallBounceR = arr (\ (r,pos,_) -> vector2X pos + r >= 1) >>> edgeTag xbounceVel

detectBounce2 :: SF Ball2 (Event Ball2)
detectBounce2 = proc b -> do
                  es <- parB [floorBounce, ceilingBounce, wallBounceL, wallBounceR] -< b
                  identity -< fmap (updateVel b) (catEvents es)
  where
    updateVel :: Ball2 -> [Velocity2 -> Velocity2] -> Ball2
    updateVel (r,p,v) fs = (r, p, foldr ($) v fs)

bouncingBall2 :: Ball2 -> SF a Ball2
bouncingBall2 b = switchWhen (fallingBall2 b) detectBounce2 bouncingBall2 

bouncingBalls :: [Ball2] -> SF a [Ball2]
bouncingBalls bs = parB (map bouncingBall2 bs)

balls2 :: [Ball2]
balls2 = [ 
           (0.01, vector2 0.2 0.6, vector2 0.4 1.5),
           (0.02, vector2 0.3 0.8, vector2 0.3 (-0.9)),
           (0.03, vector2 0.5 0.5, vector2 (-1.2) (-0.8)),
           (0.04, vector2 0.6 0.2, vector2 (-0.15) (0.2)),
           (0.05, vector2 0.4 0.6, vector2 (0.25) (0.1))
         ]

-------------------------------------------------------------------------

newBalls :: [Ball2] -> SF (Event Position2) [Ball2]
newBalls bs = newBallsAux (map bouncingBall2 bs)
              where
                newBallsAux sfs = pSwitch (\ _ sfs' -> [ ((),sf) | sf <- sfs'] )
                                          sfs
                                          (arr fst)
                                          (\ sfs' p -> notYet >>> newBallsAux (sfs' ++ [newBallSF p]))

                newBallSF :: Position2 -> SF a Ball2
                newBallSF p = let b = (0.025, p, vector2 0 0)
                               in bouncingBall2 b
                
-- pSwitch :: (forall sf. a -> [sf] -> [(b,sf)])
--         -> [SF b c]
--         -> SF (a,[c]) (Event e) 
--         -> [SF b c] -> e -> SF a [c]                
--         -> SF a [c]

-------------------------------------------------------------------------

-- Utilities

modify2X :: RealFloat a => (a -> a) -> Vector2 a -> Vector2 a
modify2X f v = vector2 (f x) y 
                 where (x,y) = vector2XY v

modify2Y :: RealFloat a => (a -> a) -> Vector2 a -> Vector2 a
modify2Y f v = vector2 x (f y)
                 where (x,y) = vector2XY v

switchWhen :: SF a b -> SF b (Event e) -> (e -> SF a b) -> SF a b
switchWhen sf sfe = switch (sf >>> (identity &&& sfe))

iIntegral :: VectorSpace x s => x -> SF x x 
iIntegral x = integral >>> arr (^+^ x)

-------------------------------------------------------------------------
