You will need to cabal install "yampa" and "blank-canvas".

Then try "runhaskell AnimateBall" or "runhaskell AnimateBalls".
